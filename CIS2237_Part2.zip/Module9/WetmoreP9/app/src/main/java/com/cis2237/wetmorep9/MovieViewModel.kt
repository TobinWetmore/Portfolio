package com.cis2237.wetmorep9

import androidx.lifecycle.LiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.cis2237.wetmorep9.api.MovieRepository
import com.cis2237.wetmorep9.model.Movie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MovieViewModel(private val movieRepository: MovieRepository,
                     private val savedStateHandle: SavedStateHandle) : ViewModel() {

    init { fetchPopularMovies() }

    // ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY,
    // Provides access to the instance of the Application class
    companion object{
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val savedStateHandle = createSavedStateHandle()
                val movieRepository = (this[APPLICATION_KEY] as MovieApplication).movieRepository
                MovieViewModel(
                    movieRepository = movieRepository,
                    savedStateHandle = savedStateHandle
                )
            }
        }
    }

    //Gets the list of movies
    val popularMovies: LiveData<List<Movie>> get() = movieRepository.movies
    //Gets the list of errors
    val error: LiveData<String> = movieRepository.error

    //Uses a coroutine to fetch movie data without bogging down the app.
    private fun fetchPopularMovies() {
        viewModelScope.launch(Dispatchers.IO) { movieRepository.fetchMovies() }
    }
}