package com.cis2237.wetmorep9

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.RecyclerView
import com.cis2237.wetmorep9.model.Movie
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private val movieViewModel: MovieViewModel by viewModels { MovieViewModel.Factory }

    //Create the adapter object and add an onClickListener for every movie to open the details
    //activity
    private val movieAdapter by lazy{
        MovieAdapter(object: MovieAdapter.MovieClickListener{
            override fun onMovieClick(movie: Movie) {
                openMovieDetails(movie)
            }
        })
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val recyclerView: RecyclerView = findViewById(R.id.movie_list)
        //TODO: The app doesn't crash when this line is commented out but it only shows a white screen
        recyclerView.adapter = movieAdapter

        movieViewModel.popularMovies.observe(this) { popularMovies ->
            movieAdapter.addMovies(popularMovies
                .filter {
                    it.release_date.startsWith(
                        Calendar.getInstance().get(Calendar.YEAR).toString()
                    )
                }
                .sortedBy { it.title }
            )
        }

        movieViewModel.error.observe(this) { error ->
            Toast.makeText(this, error, Toast.LENGTH_LONG).show()
        }
    }

    private fun openMovieDetails(movie: Movie) {
        //Create the intent and pass all the information for the details activity
        val intent = Intent(this, DetailsActivity::class.java).apply {
            putExtra(DetailsActivity.EXTRA_TITLE, movie.title)
            putExtra(DetailsActivity.EXTRA_RELEASE, movie.release_date)
            putExtra(DetailsActivity.EXTRA_OVERVIEW, movie.overview)
            putExtra(DetailsActivity.EXTRA_POSTER, movie.poster_path)
        }
        startActivity(intent)
    }
}
