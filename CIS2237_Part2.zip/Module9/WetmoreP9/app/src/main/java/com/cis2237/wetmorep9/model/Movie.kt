package com.cis2237.wetmorep9.model

import com.squareup.moshi.Json

//Defines the various parameters for the movie objects
data class Movie(
    val adult: Boolean = false,
    val backdrop_path: String = "",
    val id: Int = 0,
    @field:Json(name = "original_language")
    val original_language: String = "",
    @field:Json(name = "original_title")
    val original_title: String = "",
    val overview: String = "",
    val popularity: Float = 0f,
    @field:Json(name = "poster_path")
    val poster_path: String = "",
    @field:Json(name = "release_date")
    val release_date: String = "",
    val title: String = "",
    val video: Boolean = false,
    @field:Json(name = "vote_average")
    val vote_average: Float = 0f,
    @field:Json(name = "vote_count")
    val vote_count: Int = 0
)
