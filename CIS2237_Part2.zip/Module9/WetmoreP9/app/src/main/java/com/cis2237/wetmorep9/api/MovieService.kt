package com.cis2237.wetmorep9.api

import com.cis2237.wetmorep9.model.PopularMoviesResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface MovieService {
    //SQL to get movies from The Movie Database
    @GET("movie/popular")
    suspend fun getPopularMovies(@Query("api_key") apiKey: String): PopularMoviesResponse
}