/*
Tobin Wetmore
twetmore@snm.edu
EditFragment.kt
*/

package com.cis2237.wetmorep6workflow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class EditFragment : Fragment() {

    private lateinit var viewModel: MainViewModel
    //The passed task
    private val args by navArgs<EditFragmentArgs>()
    //Variables for the checkbox and Edit Text
    var name: EditText?=null
    var box: CheckBox?=null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) }

    companion object {
        @JvmStatic
        fun newInstance() = EditFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // break up the instantiation
        val view = inflater.inflate(R.layout.fragment_edit, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //instantiate the viewModel using requireActivity()
        viewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)
        //wire the name and box variables to the layout
        name = view.findViewById(R.id.taskNameEditEditText)
        box = view.findViewById(R.id.completedEditCheckBox)
        //set the currentTask values into the screen
        val passedTask : Task = args.task
        name?.setText(passedTask.taskName)
        box?.isChecked = passedTask.taskDone

        //set a listener onto the updateButton and have it call the private updateItem method
        val doneButton: Button = view.findViewById(R.id.doneEditButton)
        doneButton.setOnClickListener{
            updateTask(view)
            //navigate up
            Navigation.findNavController(view).navigateUp()
        }
    }

    //Collects the updated information and passes it circuitously to be updated by the TaskDao
    fun updateTask(view: View)
    {
        //then in updateItem, get the edited values of the edit text and checkbox
        //Pull the data from fragment
        val name = name?.text.toString()
        val done = box?.isChecked
        val passedTask : Task = args.task
        viewModel.updateTask(passedTask.taskId, name, done!!)

        findNavController().navigateUp()
    }
}