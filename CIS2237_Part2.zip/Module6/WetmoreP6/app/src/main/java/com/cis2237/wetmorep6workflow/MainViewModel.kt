/*
Tobin Wetmore
twetmore@snm.edu
MainViewModel.kt
*/

package com.cis2237.wetmorep6workflow

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(application: Application): AndroidViewModel(application) {

    //Instantiate an object of the TaskRepository in class scope
    private val repository: TaskRepository = TaskRepository(application)
    var def = mutableListOf(Task(0,"Fold the dishes", false),
        Task(0, "Mow the living room", false))
    private var allTasks = MutableLiveData<List<Task>>()

    //Call addTask
    fun addTask(task: Task){ viewModelScope.launch { repository.insertTask(task) } }

    //Call getAllTasks
    fun getAllTasks(): LiveData<List<Task>>{ return repository.allTasks!! }

    //Call updateTask
    fun updateTask(id: Int, name: String, checked: Boolean){
        viewModelScope.launch { repository.updateTask(id, name, checked) }
    }

    //Call deleteTask
    fun deleteTask(task: Task){ viewModelScope.launch { repository.deleteTask(task.taskName) }}
}