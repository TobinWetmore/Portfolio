/*
Tobin Wetmore
twetmore@snm.edu
TaskListAdapter.kt
*/

package com.cis2237.wetmorep6workflow

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskListAdapter(private val taskItemLayout: Int): RecyclerView.Adapter<TaskListAdapter.ViewHolder>() {

    //The view holder
    inner class ViewHolder(view: View, listener: OnItemClickListener) : RecyclerView.ViewHolder(view) {
        //findViewById works a lot better when it's spelled correctly
        var taskTitle: TextView = view.findViewById(R.id.taskTitle)
        var chkDone: CheckBox = view.findViewById(R.id.chkBxDone)

        init {
            taskTitle = view.findViewById(R.id.taskTitle)
            chkDone = view.findViewById(R.id.chkBxDone)
            view.setOnClickListener { listener.onItemClick(adapterPosition) }
        }
    }
    private var taskList: List<Task>? = null

    //The item click listener
    private lateinit var listener: OnItemClickListener
    interface OnItemClickListener{ fun onItemClick(position: Int) }

    //Add the item click listener
    fun setOnItemClickListener(itemClickListener: OnItemClickListener) { listener = itemClickListener }

    //Create the View and add it to the view holder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskListAdapter.ViewHolder {
        //view holder class
        val view = LayoutInflater.from(parent.context).inflate(taskItemLayout, parent, false)
        return ViewHolder(view, listener)
    }

    //Bind the elements of the task list to the view holder
    override fun onBindViewHolder(holder: TaskListAdapter.ViewHolder, position: Int) {
        holder.taskTitle.text = taskList!![position].taskName
        holder.chkDone.isChecked = taskList!![position].taskDone
    }

    //Check if the task list is null. If so, return 0. If not, return the size
    override fun getItemCount(): Int {
        if( taskList == null ) { return 0 }
        else { return taskList!!.size }
    }

    //Take a list of tasks and set them to the adapter
    fun setTaskList(tasks: List<Task>){
        taskList = tasks
        notifyDataSetChanged()
    }

    //Return a list of all tasks
    fun getAllTasks() : List<Task>? { return taskList }
}