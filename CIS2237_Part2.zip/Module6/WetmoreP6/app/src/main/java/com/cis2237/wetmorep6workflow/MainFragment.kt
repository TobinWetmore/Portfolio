/*
Tobin Wetmore
twetmore@snm.edu
MainFragment.kt
*/

package com.cis2237.wetmorep6workflow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cis2237.wetmorep6workflow.databinding.FragmentMainBinding

class MainFragment : Fragment() {
    private var taskList: LiveData<List<Task>> = MutableLiveData<List<Task>>()
    private var adapter: TaskListAdapter? = null
    private var taskRecycler: RecyclerView? = null
    lateinit var viewModel: MainViewModel
    private lateinit var binding: FragmentMainBinding

    companion object { fun newInstance() = MainFragment() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMainBinding.inflate(inflater)
        //return view
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Instantiate the view model using requireActivity()
        //That will allow the shared view model
        viewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)

        //call the three setup methods: Listener, observer, and recycler
        listenerSetup(view)
        observerSetup()
        recyclerSetup(view)

        //set the item click listener to go to the edit fragment
        adapter?.setOnItemClickListener(object : TaskListAdapter.OnItemClickListener{
            override fun onItemClick(position: Int){
                val currentTask = viewModel.getAllTasks().value?.get(position)
                //create an action to pass the option to the EditTaskFragment
                val action = MainFragmentDirections.actionMainToEdit(currentTask!!)
                //navigate using the action
                Navigation.findNavController(view).navigate(action)
            }
        })

        //Create the swipeToDeleteCallback and override onSwiped so tasks can be deleted
        val swipeToDeleteCallback = object: SwipeToDeleteCallback(){
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                //get the position of the row you are swiping
                val position: Int = viewHolder.adapterPosition
                //get the tasks
                val tasks: List<Task> = adapter!!.getAllTasks()!!
                //The task at needed position
                val deletedItem: Task? = tasks[position]

                //An alert dialog lets the user back out
                val builder = AlertDialog.Builder(requireContext())
                builder.setPositiveButton("Yes") { _, _ ->
                    tasks?.get(position)?.let { viewModel?.deleteTask(it) }
                }
                builder.setNegativeButton("No") { _, _ -> adapter?.notifyDataSetChanged() }
                builder.setMessage("Are you sure you want to delete ${deletedItem?.taskName}")
                builder.create().show()
            }
        }

        val itemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchHelper.attachToRecyclerView(taskRecycler)
    }

    //Add an onClickListener for the addFab
    private fun listenerSetup(view: View) {
        binding.addFab.setOnClickListener{
            val action = MainFragmentDirections.actionMainToAdd()
            Navigation.findNavController(view).navigate(action)
        }
    }

    //Set up the RecyclerView, Adapter, and binding
    private fun recyclerSetup(view: View) {
        taskRecycler = view.findViewById(R.id.taskRecycler)
        adapter = TaskListAdapter(R.layout.list_item_task_list)
        binding.taskRecycler.layoutManager = LinearLayoutManager(this.context)
        binding.taskRecycler.adapter = adapter
    }

    //Set up all the tasks
    fun observerSetup(){
        viewModel.getAllTasks().observe(viewLifecycleOwner, Observer{
            tasks -> tasks.let{ adapter?.setTaskList(tasks) }
        })
    }
}