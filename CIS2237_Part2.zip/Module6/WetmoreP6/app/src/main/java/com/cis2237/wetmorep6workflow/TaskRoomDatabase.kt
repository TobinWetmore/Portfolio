/*
Tobin Wetmore
twetmore@snm.edu
TaskRoomDatabase.kt
*/

package com.cis2237.wetmorep6workflow

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.internal.synchronized

@Database(entities=[(Task::class)], version = 1)
abstract class TaskRoomDatabase: RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object{
        private var INSTANCE: TaskRoomDatabase? = null
        @OptIn(InternalCoroutinesApi::class)
        internal fun getDatabase(context: Context): TaskRoomDatabase? {
            synchronized(TaskRoomDatabase::class.java) {
                if (INSTANCE == null ) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                        TaskRoomDatabase::class.java, "task_database").build()
                }
            }
            return INSTANCE
        }
    }
}