/*
Tobin Wetmore
twetmore@snm.edu
TaskRepository.kt
*/

package com.cis2237.wetmorep6workflow

import android.app.Application
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TaskRepository(application: Application) {
    private var taskDao: TaskDao?
    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    val allTasks: LiveData<List<Task>>?

    //instantiate the taskDao and fill the Task List
    init{
        val db: TaskRoomDatabase? = TaskRoomDatabase.getDatabase(application)
        taskDao = db?.taskDao()
        allTasks = taskDao?.getAllTasks()
    }

    //Call the insertTask with a coroutine
    fun insertTask(newTask: Task) {
        coroutineScope.launch(Dispatchers.IO) {
            asyncInsert(newTask)
        }
    }

    private fun asyncInsert(task: Task) {
        taskDao?.insertTask(task)
    }

    //Call the updateTask with a coroutine
    fun updateTask(id: Int, name: String, checked: Boolean) {
        coroutineScope.launch(Dispatchers.IO) {
            asyncUpdate(id, name, checked)
        }
    }

    private fun asyncUpdate(id: Int, name: String, checked: Boolean) {
        taskDao?.updateTask(id, name, checked)
    }

    //Call the deleteTask with a coroutine
    fun deleteTask(name: String) {
        coroutineScope.launch(Dispatchers.IO) { asyncDelete(name) }
    }

    private fun asyncDelete(name: String) {
        taskDao?.deleteTask(name)
    }
}