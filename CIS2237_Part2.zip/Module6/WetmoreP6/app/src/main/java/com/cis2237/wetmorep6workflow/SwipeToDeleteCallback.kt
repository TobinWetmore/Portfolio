/*
Tobin Wetmore
twetmore@snm.edu
SwipeToDeleteCallback.kt
*/

package com.cis2237.wetmorep6workflow

import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

abstract class SwipeToDeleteCallback : ItemTouchHelper.Callback() {
    //Sets the swipe direction
    override fun getMovementFlags(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) : Int{
        val swipeFlag = ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        return makeMovementFlags(0, swipeFlag)
    }

    override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder,
                        target: RecyclerView.ViewHolder) : Boolean {return false}

}