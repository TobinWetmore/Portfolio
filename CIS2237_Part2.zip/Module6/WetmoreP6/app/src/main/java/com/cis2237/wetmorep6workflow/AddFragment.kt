/*
Tobin Wetmore
twetmore@snm.edu
AddFragment.kt
*/

package com.cis2237.wetmorep6workflow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation

class AddFragment : Fragment() {

    lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) }

    companion object {
        @JvmStatic
        fun newInstance() = AddFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_add, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)
        //create a button variable and wire it to the widget.
        val doneButton: Button = view.findViewById(R.id.doneAddButton)

        //set an onClickListener on the button
        doneButton.setOnClickListener{
            //Pull the data from fragment
            val taskName: EditText = view.findViewById(R.id.taskNameAddEditText)
            val taskDone: CheckBox = view.findViewById(R.id.completedAddCheckBox)
            val name: String = taskName.text.toString()
            val done: Boolean = taskDone.isChecked
            //Create a new task object and put the task name into the constructor
            val newTask = Task(0, name, done)
            viewModel.addTask(newTask)
            //navigate up
            Navigation.findNavController(view).navigateUp()
        }
    }
}