/*
Tobin Wetmore
twetmore@snm.edu
TaskDao.kt
*/

package com.cis2237.wetmorep6workflow

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TaskDao {
    @Insert
    fun insertTask(task: Task)

    //"If you want to make people angry, don't pronounce SQL 'Sequel', call it Squeel."
    //-My Uncle Doug

    @Query("UPDATE tasks SET taskName = :name, taskChecked = :checked WHERE taskID = :id")
    fun updateTask(id: Int, name: String, checked: Boolean)

    @Query("DELETE FROM tasks WHERE taskName = :name")
    fun deleteTask(name: String)

    @Query("SELECT * FROM tasks")
    fun getAllTasks(): LiveData<List<Task>>
}