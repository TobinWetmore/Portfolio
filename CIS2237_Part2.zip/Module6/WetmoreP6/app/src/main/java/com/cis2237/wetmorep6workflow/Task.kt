/*
Tobin Wetmore
twetmore@snm.edu
Task.kt
*/

package com.cis2237.wetmorep6workflow

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Parcelize
//import dependencies
@Entity(tableName="tasks")
data class Task (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "taskID")
    var taskId: Int = 0,
    @ColumnInfo(name = "taskName")
    var taskName: String = "",
    @ColumnInfo(name = "taskChecked")
    var taskDone: Boolean = false
) : Parcelable