package com.cis2237.wetmorep7;

public class Car {
    //Car Name
    private String name;
    //Car Body Type
    private String bodyType;

    //Car Miles per Gallon
    private double mpg;

    //Sedan array
    //Source: https://www.kbb.com/cars/most-fuel-efficient-sedans/
    static final public Car[] sedans = {new Car("2022 Honda Insight", "Sedan", 52.0),
            new Car("2023 Toyota Crown", "Sedan", 41.0),
            new Car("2024 Mitsubishi Mirage", "Sedan", 37.0),
            new Car("2024 Hyundai Elantra", "Sedan", 36.0),
            new Car("2022 Hyundai Accent", "Sedan", 36.0),
    };

    //SUV array
    //Source: https://www.kbb.com/suv/most-fuel-efficient-suvs/
    static final public Car[] suvs = {new Car("2023 Toyota Venza", "SUV", 39.0),
            new Car("2023 Nissan Rogue", "SUV", 33.0),
            new Car("2024 Toyota Carolla Cross", "SUV", 32.0),
            new Car("2024 Kia Seltos", "SUV", 31.0),
            //The Trailblazer is actually number 6 on the list but it has the same MPG as the
            //Hyundai Venue and I like Chevrolet better
            new Car("2024 Chevrolet Trailblazer", "SUV", 31.0),
    };

    //Truck array
    //Source: https://www.kbb.com/suv/most-fuel-efficient-trucks/
    static final public Car[] trucks = {
            //There were two different versions of the GMC Sierra 1500 listed from different years.
            //I cut one
            new Car("2022 GMC Sierra 1500", "Truck", 24.0),
            new Car("2024 Dodge Ram 1500", "Truck", 22.0),
            new Car("2023 Chevrolet Colorado", "Truck", 22.0),
            new Car("2023 Toyota Tacoma", "Truck", 21.0),
            //The purist say the Ridgeline isn't a truck. Clearly, I don't care.
            new Car("2023 Honda Ridgeline", "Truck", 21.0),
    };

    //Coupé array. There are a lot of winners on this list.
    //And yes, I spell it the European way. I watched too much Top Gear as a kid.
    //Source: https://www.kbb.com/suv/most-fuel-efficient-coupes/
    static final public Car[] coupes = {new Car("2024 Toyota GR Supra", "Coupé", 27.0),
            new Car("2024 Ford Mustang", "Coupé", 26.0),
            //The Subaru BRZ and Toyota GR86 were tied in this spot. I cut the Subaru because I'm a
            //big Toyota fan and they are the same car.
            new Car("2023 Toyota GR86", "Coupé", 25.0),
            //A bit of an odd choice for this list. It's half coupé and half regular hatchback, with
            //one door on the drivers side and two on the other. Solid car though, they're fun.
            new Car("2022 Hyundai Veloster", "Coupé", 25.0),
            new Car("2023 Dodge Challenger", "Coupé", 23.0),
    };

    //Bonus array
    //Source: A C++ project I did many years ago. I think that was my first class with you.
    static final public Car[] secret = {new Car("2001 Toyota MR2 Spyder", "Coupé", 26.0),
            new Car("2020 FIAT 124 Spider", "Coupé", 26.0),
            new Car("2019 Ferrari 488 Spider", "Coupé", 15.0),
            new Car("2015 Porsche 918 Spyder", "Coupé", 20.0),
            //My original source: https://www.governing.com/idea-center/Phasing-Out-The-Big-Red-Fire-Truck.html
            //I talked to a firefighter since I wrote the first project and they said that number
            //seemed accurate
            new Car("Fire Truck", "Fire Truck", 3.6),
    };

    //Constructor
    public Car(String name, String bodyType, double mpg)
    {
        this.name = name;
        this.bodyType = bodyType;
        this.mpg = mpg;
    }

    //Getters and setter
    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getBodyType() { return bodyType; }

    public void setBodyType(String bodyType) { this.bodyType = bodyType; }

    public double getMpg() { return mpg; }

    public void setMpg(double mpg) { this.mpg = mpg; }
}
