package com.cis2237.wetmorep7;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cis2237.wetmorep7.databinding.FragmentQuizBinding;

public class QuizFragment extends Fragment
{
    private FragmentQuizBinding binding;

    @Override
    public void onStart()
    {
        //Take the passed string argument
        super.onStart();
        QuizFragmentArgs args = QuizFragmentArgs.fromBundle(getArguments());

        //Use the passed string to figure out which array to use to populate the buttons
        //TODO: Randomize the order
        if(args.getBodyType() == "Sedan")
        {
            binding.btnOne.setText(Car.sedans[0].getName());
            binding.btnTwo.setText(Car.sedans[1].getName());
            binding.btnThree.setText(Car.sedans[2].getName());
            binding.btnFour.setText(Car.sedans[3].getName());
            binding.btnFive.setText(Car.sedans[4].getName());
        }
        if(args.getBodyType() == "SUV")
        {
            binding.btnOne.setText(Car.suvs[0].getName());
            binding.btnTwo.setText(Car.suvs[1].getName());
            binding.btnThree.setText(Car.suvs[2].getName());
            binding.btnFour.setText(Car.suvs[3].getName());
            binding.btnFive.setText(Car.suvs[4].getName());
        }
        if(args.getBodyType() == "Truck")
        {
            binding.btnOne.setText(Car.trucks[0].getName());
            binding.btnTwo.setText(Car.trucks[1].getName());
            binding.btnThree.setText(Car.trucks[2].getName());
            binding.btnFour.setText(Car.trucks[3].getName());
            binding.btnFive.setText(Car.trucks[4].getName());
        }
        if(args.getBodyType() == "Coupe")
        {
            binding.btnOne.setText(Car.coupes[0].getName());
            binding.btnTwo.setText(Car.coupes[1].getName());
            binding.btnThree.setText(Car.coupes[2].getName());
            binding.btnFour.setText(Car.coupes[3].getName());
            binding.btnFive.setText(Car.coupes[4].getName());
        }
        if(args.getBodyType() == "Secret")
        {
            binding.btnOne.setText(Car.secret[0].getName());
            binding.btnTwo.setText(Car.secret[1].getName());
            binding.btnThree.setText(Car.secret[2].getName());
            binding.btnFour.setText(Car.secret[3].getName());
            binding.btnFive.setText(Car.secret[4].getName());
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        binding.btnOne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                QuizFragmentDirections.ActionQuizToAnswer action = QuizFragmentDirections.actionQuizToAnswer(Cars)
            }
        });
    }

    public interface OnFragmentInteractionListener { void onFragmentInteraction(Uri uri); }
    public QuizFragment() { }
    public static QuizFragment newInstance() { return new QuizFragment(); }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        binding = FragmentQuizBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
}