package com.cis2237.wetmorep7;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.cis2237.wetmorep7.databinding.FragmentMainBinding;
public class MainFragment extends Fragment
{
    //Parameters to keep track of if the user has done every section
    private boolean sedanBool = false;
    private boolean suvBool = false;
    private boolean truckBool = false;
    private boolean coupeBool = false;

    //Buttons
    private Button btnSedan;
    private Button btnSUV;
    private Button btnTruck;
    private Button btnCoupe;
    private Button btnSecret;
    private FragmentMainBinding binding;
    public MainFragment() { }
    public static MainFragment newInstance() { return new MainFragment(); }

    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnSedan = binding.btnSedan;
        btnSUV = binding.btnSUV;
        btnTruck = binding.btnTruck;
        btnCoupe = binding.btnCoupe;
        btnSecret = binding.btnSecret;
        btnSecret.setVisibility(View.INVISIBLE);

        binding.btnSedan.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                sedanBool = true;
                checkCompletion();
                MainFragmentDirections.ActionMainToQuiz action = MainFragmentDirections.actionMainToQuiz();
                action.setCarArray(Car.sedans);
                Navigation.findNavController(view).navigate(action);
            }
        });

        binding.btnSUV.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                suvBool = true;
                checkCompletion();
                MainFragmentDirections.ActionMainToQuiz action = MainFragmentDirections.actionMainToQuiz();
                action.setBodyType("SUV");
                Navigation.findNavController(view).navigate(action);
            }
        });

        binding.btnTruck.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                truckBool = true;
                checkCompletion();
                MainFragmentDirections.ActionMainToQuiz action = MainFragmentDirections.actionMainToQuiz();
                action.setBodyType("Truck");
                Navigation.findNavController(view).navigate(action);
            }
        });

        binding.btnCoupe.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                coupeBool = true;
                checkCompletion();
                MainFragmentDirections.ActionMainToQuiz action = MainFragmentDirections.actionMainToQuiz();
                action.setBodyType("Coupé");
                Navigation.findNavController(view).navigate(action);
            }
        });

        binding.btnSecret.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                MainFragmentDirections.ActionMainToQuiz action = MainFragmentDirections.actionMainToQuiz();
                action.setBodyType("Secret");
                Navigation.findNavController(view).navigate(action);
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        binding = FragmentMainBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    //If the user has done every test, the secret one is unlocked.
    private void checkCompletion()
    {
        if(sedanBool && suvBool && truckBool && coupeBool)
        {
            btnSecret.setVisibility(View.VISIBLE);
        }
    }
}