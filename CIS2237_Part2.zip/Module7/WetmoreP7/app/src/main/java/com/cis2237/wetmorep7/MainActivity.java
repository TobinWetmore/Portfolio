package com.cis2237.wetmorep7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements QuizFragment.OnFragmentInteractionListener
{
    //Strings for the toasts
    private String tst = "CIS 2237 Android Programming \r\nTobin Wetmore, Project 7";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, tst,   Toast.LENGTH_LONG);
        toast.show();
    }

    @Override
    public void onFragmentInteraction(Uri uri) { }
}