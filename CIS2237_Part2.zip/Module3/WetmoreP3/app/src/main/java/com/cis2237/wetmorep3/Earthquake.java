/*
Tobin Wetmore
Program 3: EarthquakeViewer
Fragments, DataBinding, and RecyclerView
*/

package com.cis2237.wetmorep3;

import android.location.Location;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Earthquake
{
    //Fields
    String id;
    Date date;
    String details;
    Location location;
    double magnitude;
    String link;

    //Constructor
    public Earthquake(String id, Date date, String details, Location location, double magnitude, String link)
    {
        this.id = id;
        this.date = date;
        this.details = details;
        this.location = location;
        this.magnitude = magnitude;
        this.link = link;
    }

    //To String that includes all the fields, nicely formatted.
    @Override
    public String toString()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("HH.mm", Locale.US);
        String dateString = sdf.format(date);
        String description = "Date: " + dateString + ", Magnitude: " + magnitude + "\r\n" + details;
        return description;
    }

    //Checks if the id fields on two earthquakes are the same.
    @Override
    public boolean equals(@Nullable Object obj)
    {
        //Cast obj to an Earthquake so it has an id
        Earthquake temp = (Earthquake) obj;
        //Determine if the passed earthquake object equals this earthquake object.
        if ( this.id == temp.id ) { return true; }
        else { return false; }
    }

    //Getters
    public String getId() { return id; }

    public Date getDate() { return date; }

    public String getDetails() { return details; }

    public Location getLocation() { return location; }

    public double getMagnitude() { return magnitude; }

    public String getLink() { return link; }
}
