/*
Tobin Wetmore
Program 3: EarthquakeViewer
Fragments, DataBinding, and RecyclerView
*/

package com.cis2237.wetmorep3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}