/*
Tobin Wetmore
Program 3: EarthquakeViewer
Fragments, DataBinding, and RecyclerView
*/

package com.cis2237.wetmorep3;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cis2237.wetmorep3.databinding.ListItemEarthquakeBinding;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class EarthquakeRecyclerViewAdapter extends RecyclerView.Adapter<EarthquakeRecyclerViewAdapter.ViewHolder>
{
    //An array list of the earthquakes
    private ArrayList<Earthquake> earthquakes;


    //The constructor that takes and sets earthquakes
    public EarthquakeRecyclerViewAdapter(ArrayList<Earthquake> earthquakes) { this.earthquakes = earthquakes; }
    //Date formatter
    private final static DateFormat TIME_FORMAT = new SimpleDateFormat("HH.mm", Locale.US);
    //Magnitude formatter
    private final static NumberFormat MAGNITUDE_FORMAT = new DecimalFormat("0.0");

    @NonNull
    @Override
    public EarthquakeRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //Create and return the data binding
        ListItemEarthquakeBinding binding = ListItemEarthquakeBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EarthquakeRecyclerViewAdapter.ViewHolder holder, int position)
    {
        //Sets a temporary earthquake
        Earthquake  earthquake =  earthquakes.get(position);
        //Binds the earthquake
        holder.binding.setEarthquake(earthquake);
        holder.binding.executePendingBindings();
    }

    @Override
    public int getItemCount()
    {
        //Added the check for the null. It keeps crashing otherwise.
        //The earthquakes arraylist is always null for some reason.
        if( earthquakes != null ) { return earthquakes.size(); }
        else { return 0; }
    }

    class ViewHolder extends RecyclerView.ViewHolder
    {
        //Instantiate the binding
        public final ListItemEarthquakeBinding binding;
        public ViewHolder(ListItemEarthquakeBinding binding)
        {
            //Call the super and set the binding
            super(binding.getRoot());
            this.binding = binding;
            //add the formatting for time and magnitude
            //Things keep breaking.
            binding.setTimeformat(TIME_FORMAT);
            binding.setMagnitudeformat(MAGNITUDE_FORMAT);
        }

        //add a toString() method that calls the super and adds the earthquake
        @Override
        public String toString()
        {
            return super.toString() + earthquakes.toString();
        }
    }
}
