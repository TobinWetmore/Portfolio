/*
Tobin Wetmore
Program 5: EarthquakeViewer
Settings Fragment, Collapsing Toolbar, Appbar, Toolbar layouts, Shared Preferences, and Splash Screen
*/

package com.cis2237.wetmorep5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String tst = "CIS 2237 Android Programming \r\nTobin Wetmore, Project 5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, tst,   Toast.LENGTH_LONG);
        toast.show();
    }
}