/*
Tobin Wetmore
Program 5: EarthquakeViewer
Settings Fragment, Collapsing Toolbar, Appbar, Toolbar layouts, Shared Preferences, and Splash Screen
*/

package com.cis2237.wetmorep5;

import static com.cis2237.wetmorep5.R.id.list;
import com.cis2237.wetmorep5.MainViewModel;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class EarthquakeListFragment extends Fragment
{
    private ArrayList<Earthquake> earthquakes = new ArrayList<>();
    private RecyclerView recyclerView;
    private EarthquakeRecyclerViewAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    //Don't instantiate the ViewModel here, the opposite of my problem last time
    private MainViewModel viewModel;
    public EarthquakeListFragment() { }
    public static EarthquakeListFragment newInstance() { return new EarthquakeListFragment(); }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_earthquake_list, container, false);
        recyclerView = view.findViewById(list);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        Context context = view.getContext();

        //instantiate adapter
        adapter = new EarthquakeRecyclerViewAdapter(earthquakes);
        //set the layout manager into the recycler view
        layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        //set the adapter into the recycler view
        recyclerView.setAdapter(adapter);

        //Instantiate the ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        //Add an observer to track when data changes
        viewModel.getEarthquakes().observe(getViewLifecycleOwner(), new Observer<List<Earthquake>>()
        {
            @Override
            public void onChanged(@Nullable List<Earthquake> earthquakes)
            {
                //Updates the arraylist as long as the passed values exist
                if( earthquakes != null )
                {
                    setEarthquakes(earthquakes);
                    adapter.notifyItemInserted(earthquakes.indexOf(earthquakes));
                }
            }
        });

        /*Old code. I'll miss the earthquake in Omaha.
        //add dummy earthquakes, import Calendar and Date
        //Get Date now
        Date date = Calendar.getInstance().getTime();
        Earthquake quakeOne = new Earthquake("dummyOne", date, "How did that happen?", new Location( "Omaha" ), 9.0, null);
        Earthquake quakeTwo = new Earthquake("dummyTwo", date, "That makes more sense.", new Location( "Tokyo" ), 6.3, null);

        //Create a new local list of earthquakes, dummyQuakes
        ArrayList<Earthquake> dummyQuakes = new ArrayList();

        //Add two earthquake objects to the dummyQuakes list
        dummyQuakes.add(quakeOne);
        dummyQuakes.add(quakeTwo);

        this.setEarthquakes(dummyQuakes);
        */
    }

    //Pass setEarthquakes a List because this program uses three different List types and we need
    //the loosest definition
    public void setEarthquakes(List<Earthquake> list)
    {
        //Use a for-each loop to iterate through the passed list
        for(Earthquake newQuake : list)
        {
            if ( !earthquakes.contains(newQuake) )
            {
                earthquakes.add(newQuake);
                adapter.notifyDataSetChanged();
            }
        }
    }
}