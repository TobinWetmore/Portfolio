/*
Tobin Wetmore
Program 5: EarthquakeViewer
Settings Fragment, Collapsing Toolbar, Appbar, Toolbar layouts, Shared Preferences, and Splash Screen
*/

package com.cis2237.wetmorep5;

import android.app.Application;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MainViewModel extends AndroidViewModel
{
    private static final String link = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.atom";
    private static final String TAG = "EarthquakeUpdate";
    MutableLiveData<List<Earthquake>> quakes;
    private Handler handler;
    public MainViewModel(@NonNull Application application)
    {
        super(application);
        handler = new Handler(Looper.getMainLooper());
    }

    public LiveData<List<Earthquake>> getEarthquakes()
    {
        //Make sure quakes is instantiated. I had enough trouble with that.
        if( quakes == null ) { quakes = new MutableLiveData<List<Earthquake>>(); }
        loadEarthquakes();
        return quakes;
    }

    //Get the array list of earthquakes from the internet
    private void loadEarthquakes()
    {
        //Make a new thread to avoid bogging down the program
         new Thread(new Runnable()
         {
             //Instantiate a temporary array list of earthquakes
             List<Earthquake> quakeList = new ArrayList<>();

             @Override
             public void run()
             {
                 try
                 {
                     //All the code to make and verify the connection
                     URL url = new URL(link);
                     //Trying to access it from the string resource file somehow pulls an int
                     //URL url = new URL(String.valueOf(R.string.earthquake_feed));
                     URLConnection connection = url.openConnection();
                     HttpURLConnection httpConnection = (HttpURLConnection) connection;
                     int responseCode = httpConnection.getResponseCode();
                     if ( responseCode == HttpURLConnection.HTTP_OK )
                     {
                         //All the preparatory stuff to parsing the data
                         InputStream istream = httpConnection.getInputStream();
                         DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
                         DocumentBuilder documentBuilder = builderFactory.newDocumentBuilder();
                         Document document = documentBuilder.parse(istream);
                         NodeList nodeList = document.getElementsByTagName("entry");
                         for (int i = 0; i < nodeList.getLength(); i++)
                         {
                             if ( nodeList.item(0).getNodeType() == Node.ELEMENT_NODE )
                             {
                                 Element entry = (Element) nodeList.item(i);
                                 Element id = (Element) entry.getElementsByTagName("id").item(0);
                                 Element title = (Element) entry.getElementsByTagName("title").item(0);
                                 Element g = (Element) entry.getElementsByTagName("georss:point").item(0);
                                 Element when = (Element) entry.getElementsByTagName("updated").item(0);
                                 Element link = (Element) entry.getElementsByTagName("link").item(0);
                                 String idString = id.getFirstChild().getNodeValue();
                                 String details = title.getFirstChild().getNodeValue();
                                 String hostname = "http://earthquake.usgs.gov";
                                 String linkString = hostname + link.getAttribute("href");
                                 String point = g.getFirstChild().getNodeValue();
                                 String dt = when.getFirstChild().getNodeValue();
                                 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSS'Z'");
                                 Date qdate = new GregorianCalendar(0, 0, 0).getTime();
                                 try { qdate = sdf.parse(dt); }
                                 catch (ParseException e) { Log.e(TAG, "Date parsing exception.", e); }
                                 String[] location = point.split(" ");
                                 Location l = new Location("dummyGPS");
                                 l.setLatitude(Double.parseDouble(location[0]));
                                 l.setLongitude(Double.parseDouble(location[1]));
                                 String magnitudeString = details.split(" ")[1];
                                 int end = magnitudeString.length();
                                 double magnitude = Double.parseDouble(magnitudeString.substring(0, end));
                                 if (details.contains("-")) { details = details.split("-")[1].trim(); }
                                 else { details = ""; }
                                 //Add the new earthquake to the temporary list
                                 quakeList.add(new Earthquake(idString, qdate, details, l, magnitude, linkString));
                             }
                         }
                     }
                 }
                 //A whole bunch of exceptions. Hopefully Android Studio is smart enough to pick the
                 //correct ones.
                 catch (MalformedURLException e) { throw new RuntimeException(e); }
                 catch (IOException e) { throw new RuntimeException(e); }
                 catch (ParserConfigurationException e) { throw new RuntimeException(e); }
                 catch (SAXException e) { throw new RuntimeException(e); }
                 //A handler to let the separate thread update the screen.
                 handler.post(new Runnable()
                 {
                     @Override
                     public void run()  { quakes.setValue(quakeList);}
                 });
             }
         //Now we can finally start the background thread.
         }).start();
    }
}
