/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis2235.wetmorep5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.spi.DirStateFactory.Result;
import javax.swing.JOptionPane;
import javax.swing.text.TabExpander;

/**
 *
 * @author inelson1
 */
public class DBManager {

    private Connection connection = null;
    private Statement statement = null;
    private final String TABLE_NAME = "WetmoreCars";

    //Constructor established the connection to the database
    public DBManager()
    {
        try
        {
            // Establish a connection
            //Set the database name here.  Default is sample
            connection = DriverManager.getConnection("jdbc:sqlite:wetmorep5.db");

        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insert(int recordID, String make, String model, int year, String type)
    {
        try
        {
            //Insert a new record into the database
            String insertQuery = "INSERT INTO " + TABLE_NAME + " VALUES (?, ?, ? , ?, ?)";

            PreparedStatement  insertUpdate = null;
            insertUpdate = connection.prepareStatement(insertQuery);

            insertUpdate.setInt(1, recordID);
            insertUpdate.setString(2, make);
            insertUpdate.setString(3, model);
            insertUpdate.setInt(4, year);
            insertUpdate.setString(5, type);
            insertUpdate.executeUpdate();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int getLastID()
    {
        int ID = 0;
        ResultSet results;
        try
        {
            statement = connection.createStatement();

            String newQuery = "SELECT MAX(ID)" + "FROM " + TABLE_NAME;
            results = statement.executeQuery(newQuery);

            if (results.next())
            {
                ID = Integer.parseInt(results.getString(1));
            }

        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return ID;
    }

    public String[] getRecordById(int recordID)
    {

        String make = "";
        String model= "";
        String strYear = "";
        String type = "";

        try
        {
            PreparedStatement getRecordStmt = null;

            //Display the contents of the record

            String getRecordQuery = "SELECT * " + "FROM " + TABLE_NAME + " WHERE ID = ?";//+ recordID;
            getRecordStmt = connection.prepareStatement(getRecordQuery);
            getRecordStmt.setInt(1, recordID);

            ResultSet result = getRecordStmt.executeQuery();

            if(result.next())
            {
                make = result.getString(2);
                model = result.getString(3);
                strYear = result.getString(4);
                type = result.getString(5);
            }

        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        String[] getRow = {make, model, strYear, type};
        return getRow;
    }

    public void editRecord(int recordID, String make, String model, int year, String type)
    {
        try
        {
            PreparedStatement  editStatement = null;
            //update the record
            String editQuery = "UPDATE " + TABLE_NAME + " SET MAKE = ?, MODEL = ?, YEAR = ?, TYPE = ? WHERE ID = ?";
            editStatement = connection.prepareStatement(editQuery);

            editStatement.setString(1, make);
            editStatement.setString(2, model);
            editStatement.setInt(3, year);
            editStatement.setString(4, type);
            editStatement.setInt(5, recordID);
            editStatement.executeUpdate();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteRecord(int  recordID)
    {
        try
        {
            PreparedStatement deleteStmt = null;
            //Delete the record.
            String deleteQuery = "DELETE FROM " + TABLE_NAME + " WHERE ID = ?";
            deleteStmt = connection.prepareStatement(deleteQuery);
            deleteStmt.setInt(1, recordID);
            deleteStmt.executeUpdate();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Classes for creating the table and putting values in it.

    //Create a table
    public void createTable()
    {
        //  statement.executeUpdate
        String sql = "CREATE TABLE IF NOT EXISTS WetmoreCars ( \n"
                + "   id integer PRIMARY KEY, \n"
                + "   MAKE text NOT NULL, \n"
                + "   MODEL text NOT NULL, \n"
                + "   YEAR integer NOT NULL, \n"
                + "   TYPE text Not Null\n"
                + ");";
        //Using SQL:
//                    + "(ID NUMBER(3) NOT NULL PRIMARY KEY, "
//                        + "MAKE Varchar2(30) NOT NULL, "
//                        + "MODEL Varchar2(30) NOT NULL , "
//                        + "YEAR NUMBER(2) NOT NULL , "
//                        + "TYPE Varchar2(30) NOT NULL )");
        try
        {
            statement = connection.createStatement();
            statement.executeUpdate(sql);
        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void populateDatabase()
    {
        //Cars I've worked on. Doesn't make the most sense for a database, but the data is good.
        insert(1, "Toyota", "MR2 Spyder", 2001, "Roadster");
//        insert(2, "Toyota", "Highlander", 2016, "SUV");
//        //My dad really likes Firebirds. I wish he was into the Trans Am instead, but whatever.
//        insert (3, "Pontiac", "Firebird", 1994, "Coupe");
//        insert (4, "Pontiac", "Firebird", 1997, "Coupe");
//        //My dad and brother both have Ramblers.
//        insert (5, "AMC", "Rambler", 1969, "Sedan");
//        insert (6, "AMC", "Rambler", 1964, "Sedan");
    }

    public void dropTable()
    {
        try
        {
            statement = connection.createStatement();

            //Be sure to change the name of the table
            String drop = "Drop Table " + TABLE_NAME + " " ;
            statement.execute(drop);
        }
        catch (SQLException ex)
        {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
