package com.cis2235.wetmorep5;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import javax.swing.*;

public class HelloController {

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnDisplay;

    @FXML
    private Button btnDisplayTable;

    @FXML
    private Button btnEdit;

    @FXML
    private Button btnEnterID;

    @FXML
    private Button btnInsert;

    @FXML
    private Button btnPopulateTable;

    @FXML
    private ListView<String> lvData;

    @FXML
    private TextField txtfdRecordID;

    @FXML
    private TextField txtfdMake;

    @FXML
    private TextField txtfdModel;

    @FXML
    private TextField txtfdType;

    @FXML
    private TextField txtfdYear;

    private int recordID;
    private String make;
    private String model;
    private int year;
    private String type;

    private DBManager manager = new DBManager();

    private ObservableList<String> carList = FXCollections.observableArrayList();

    @FXML
    void handleDelete(ActionEvent event)
    {
        //Add exception handling or check with code
        //read the string from txtfdRecordID and cast to an int
        try
        {
            recordID = Integer.parseInt(txtfdRecordID.getText());
            //RecordID has a value now.
            manager.deleteRecord(recordID);
        }
        catch ( Exception e )
        {
            JOptionPane.showMessageDialog(null, "Please enter an Integer in the ID Field.");
        }

        clearTextFields();
        displayDB();
    }

    @FXML
    void handleDisplay(ActionEvent event)
    {
        displayDB();
    }

    @FXML
    void handleCreateTable(ActionEvent event)
    {
        manager.createTable();
    }

    @FXML
    void handleEdit(ActionEvent event)
    {
        getRecordValues();
        //manager.editRecord(with the class variable)
        manager.editRecord(recordID,make,model,year,type);
        clearTextFields();
        displayDB();
    }

    @FXML
    void handleEnterID(ActionEvent event)
    {
        //get the record ID from the text field
        //read the string from txtfdRecordID and cast to an int
        try
        {
            recordID = Integer.parseInt(txtfdRecordID.getText());
        }
        catch ( Exception e )
        {
            JOptionPane.showMessageDialog(null, "Please enter an Integer in the ID Field.");
        }
        //create an array of columns or values or editRow (Strings). This doesn't include the recordID
        String[] edit = new String[4];
        edit = manager.getRecordById(recordID);

        //Assign  element 0 to the first column. (again, not counting the recordID)
        txtfdMake.setText(edit[0]);
        txtfdModel.setText(edit[1]);
        txtfdYear.setText(edit[2]);
        txtfdType.setText(edit[3]);
    }

    @FXML
    void handleInsert(ActionEvent event)
    {
        //Get the record value from the text field
        getRecordValues();
        //get the last ID
        recordID = manager.getLastID();
        //call and assign the return into the recordID variable
        manager.getLastID();
        //New entry has ID of manager.getLastID() + 1;
        //manager.insert(columns of the record);
        manager.insert(recordID + 1, make, model, year, type);
        //clear the text fields
        clearTextFields();
        displayDB();
    }

    @FXML
    void handlePopulateTable(ActionEvent event)
    {
        manager.populateDatabase();
        displayDB();
    }

    public void displayDB()
    {
        //start by clearing carList
        carList.clear();
        //get the number of records that you have by using getLastID();
        int max = manager.getLastID();
        //Create an array of Strings that is the number of columns
        String[] temp = new String[4];
        //Start a for loop starting at 0 <= number of records
        for (int i = 0; i < max; i++)
        {
            //Get the recordByID(i) and assign to the String array at i
            temp = manager.getRecordById(i + 1);
            //check if the record is blank, call continue keyword
            if (temp[0] == "" && temp[1] == "" && temp[2] == "" && temp[3] == "")
            {
                continue;
            }
            //else, add to the arrayList, format a String: i + "|" string array at 0 + "|" + string array at 1...
            else
            {
                carList.add(i + 1 + " | " + temp[0] + " | " + temp[1] + " | " + temp[2] + " | " + temp[3]);
            }
        }
        //Call lvData.setItems(carList);
        lvData.setItems(carList);
    }

    private void getRecordValues()
    {
        //Get Strings out of the text fields
        //Assign into the Controller class variables.
        make = txtfdMake.getText();
        model = txtfdModel.getText();
        //read the string from txtfdYear and cast to an int
        try
        {
            year = Integer.parseInt(txtfdYear.getText());
        }
        catch ( Exception e )
        {
            JOptionPane.showMessageDialog(null, "Please enter an Integer in the Year Field.");
        }
        type = txtfdType.getText();
    }

    private void clearTextFields()
    {
        //Set the text fields to blank Strings.
        txtfdRecordID.setText("");
        txtfdMake.setText("");
        txtfdModel.setText("");
        txtfdYear.setText("");
        txtfdType.setText("");
    }
}
