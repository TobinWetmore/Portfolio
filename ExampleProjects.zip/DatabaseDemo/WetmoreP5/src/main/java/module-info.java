module com.cis2235.wetmorep5 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires java.naming;
    requires java.desktop;

    opens com.cis2235.wetmorep5 to javafx.fxml;
    exports com.cis2235.wetmorep5;
}