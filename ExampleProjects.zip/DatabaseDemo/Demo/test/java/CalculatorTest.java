import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest
{

    //Ctrl + /
//    @Test
//    void shouldShowSimpleAssertion()
//    {
//        Assertions.assertEquals(1,1);
//
//    }

    Calculator calculator;
    @BeforeEach
    void setUp()
    {
        calculator = new Calculator();
    }

    @Disabled
    @Test
    @DisplayName("Simple multiplication should work")
    void testMultiply()
    {
        assertEquals(20, calculator.multiply(4,5), "Regular multiplication should work");
    }

//    @RepeatedTest(5)
//    @DisplayName("Ensure correct handling of zero")
//    void testMultiplyWithZero()
//    {
//        assertEquals(0,calculator.multiply(0,5),"Multiply with zero should be zero");
//        assertEquals(0, calculator.multiply(5,0),"Multiply with zero should be zero");
//    }
}