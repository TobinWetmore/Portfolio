//Tobin Wetmore
//twetmore@cnm.edu
//Main.java

public class Main
{
    public static void Main(String[] args)
    {
        Calculator calc = new Calculator();
        int x = 4;
        int y = 3;
        int res = calc.multiply(x,y);
        System.out.println("\nThe answer is " + res);
    }
}
