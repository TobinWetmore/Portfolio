//A. Noel Cothren
//acothren1@cnm.edu
//Program 6 - Blackjack Group Project

// Card.cpp file

#include "Card.h"

Card::Card(int n) //It receives a value of 0 through 51 from the Deck class.
{
	//Determines the suit of the Card  
	int iSuit = n / 13;

	//Assign the correct text to the suit variable by comparing the iSuit value to the values identified in each of the four case labels (0-3).  
	switch (iSuit)
	{
	case 0: suit = "Spades";
		break;
	case 1: suit = "Hearts";
		break;
	case 2: suit = "Clubs";
		break;
	case 3: suit = "Diamonds";
		break;
	}

	// Determines the point value of the card 
	// Cards 2-10 are worth the value of the number on the face of the card. Aces are worth 1. Face cards iValue is updated below.
	iValue = n % 13 + 1;

	// Assign the string variable values to each card.  
	//That is, if iValue == 1, value = �Ace� and if iValue == 13, value = �King�, etc for the face cards
	// and for the number cards, value = the string representation of iValue
	switch (iValue)
	{
	case 1: value = "Ace";
		break;
	case 13: value = "King";
		break;
	case 12: value = "Queen";
		break;
	case 11: value = "Jack";
		break;		
	default: value = to_string(iValue);
		break;
	}
	// Update point value for face cards (those with pictures on them). All are worth 10, except for the Ace, which is worth 1.
	if (iValue > 10) iValue = 10;
}

Card::Card()
{
}
