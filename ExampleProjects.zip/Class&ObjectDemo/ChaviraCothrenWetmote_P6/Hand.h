//Tobin Wetmore
//twetmore@cnm.edu
//Hand.h

#ifndef HAND
#define HAND

#include "Card.h"
#include <array>
#include <string>
#include <sstream>
using namespace std;

//The maximum number of cards a hand can have
const int MAX_CARDS{ 12 };
const int DEALER_TARGET{ 17 };
const int BLACKJACK{ 21 };
const int ACE{ 10 };

class Hand
{
private:
	//Number cards in the hand
	int numCards{ 0 };
	//A string to describe the cards in the hand
	string showHand;
	//an array of cards
	array<Card, MAX_CARDS> cards;

public:
	//Constructor
	Hand();
	//Takes a Card object and adds it to the first available position in the hand
	void AddCard(Card c);
	//makes a string describing the hand and uses the bools passed to it to tell if it's the user's or the computer's hand
	string Show(bool isdealer, bool hideFirstCard);
	//makes a string describing the hand and uses the bool passed to it to tell if it's the user's or the computer's hand
	string Show(bool isdealer);
	//Checks to see if the hand is BlackJack
	bool BlackJack();
	//Checks if the hand is less than the int passed to it
	bool Under(int n);
	//Determines the best possible score based on the cards in the hand
	int BestScore();
	//Checks if the dealer has to hit, if the have less than 17 points
	bool MustHit();
	//Checks if the hand has 22 or more points
	bool Busted();
	//removes all cards from the hand
	void ClearHand();
};
#endif