//A Noel Cothren
//acothren1@cnm.edu
//Program 6 Blackjack Group Project

// file = MyForm.h
#include "Game.h"

namespace ChaviraCothrenWetmoteP6 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	/// <summary>
	/// MyForm is part of an interactive Blackjack game
	/// </summary>

	Game game; //instantiate game class
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			lblHitOrStay->Visible = false;
			btnHit->Visible = false;
			btnStay->Visible = false;
			//Also check that the logFile was opened in the constructor and if the log file was not opened, report that in the Status box txtStatus. But keep playing
			if (!game.IsLogOpened()) txtStatus->Text = "Uh-oh. We could not open the log file.";
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ menu;

	protected:

	private: System::Windows::Forms::Button^ btnHit;

	private: System::Windows::Forms::Button^ btnStay;
	private: System::Windows::Forms::Label^ lblHitOrStay;

	private: System::Windows::Forms::Button^ btnPlayAgain;
	private: System::Windows::Forms::Button^ btnBet;
	private: System::Windows::Forms::TextBox^ txtStatus;
	private: System::Windows::Forms::Label^ lblStatus;
	private: System::Windows::Forms::Label^ lblHeader;
	private: System::Windows::Forms::Label^ lblForBet;
	private: System::Windows::Forms::TextBox^ txtBetAmount;
	private: System::Windows::Forms::TextBox^ txtPlayersHand;
	private: System::Windows::Forms::Label^ lblPlayersHand;
	private: System::Windows::Forms::Label^ lblDealersHand;
	private: System::Windows::Forms::TextBox^ txtDealersHand;
	private: System::Windows::Forms::ToolStripMenuItem^ menuItemRules;
	private: System::Windows::Forms::TableLayoutPanel^ tableLayoutPanel1;
	private: System::Windows::Forms::MessageBox^ msgBoxRules;
	private: System::Windows::Forms::Button^ btnQuit;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->menuItemRules = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->btnHit = (gcnew System::Windows::Forms::Button());
			this->btnStay = (gcnew System::Windows::Forms::Button());
			this->lblHitOrStay = (gcnew System::Windows::Forms::Label());
			this->btnPlayAgain = (gcnew System::Windows::Forms::Button());
			this->btnBet = (gcnew System::Windows::Forms::Button());
			this->txtStatus = (gcnew System::Windows::Forms::TextBox());
			this->lblStatus = (gcnew System::Windows::Forms::Label());
			this->lblHeader = (gcnew System::Windows::Forms::Label());
			this->lblForBet = (gcnew System::Windows::Forms::Label());
			this->txtBetAmount = (gcnew System::Windows::Forms::TextBox());
			this->txtPlayersHand = (gcnew System::Windows::Forms::TextBox());
			this->lblPlayersHand = (gcnew System::Windows::Forms::Label());
			this->lblDealersHand = (gcnew System::Windows::Forms::Label());
			this->txtDealersHand = (gcnew System::Windows::Forms::TextBox());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->btnQuit = (gcnew System::Windows::Forms::Button());
			this->menuStrip1->SuspendLayout();
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->menu });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(11, 3, 0, 3);
			this->menuStrip1->Size = System::Drawing::Size(981, 25);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// menu
			// 
			this->menu->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->menuItemRules });
			this->menu->Name = L"menu";
			this->menu->Size = System::Drawing::Size(50, 19);
			this->menu->Text = L"Menu";
			this->menu->Click += gcnew System::EventHandler(this, &MyForm::rulesOfTheGameMenu_Click);
			// 
			// menuItemRules
			// 
			this->menuItemRules->Name = L"menuItemRules";
			this->menuItemRules->Size = System::Drawing::Size(170, 22);
			this->menuItemRules->Text = L"Rules of the Game";
			this->menuItemRules->Click += gcnew System::EventHandler(this, &MyForm::rulesOfTheGameMenu_Click);
			// 
			// btnHit
			// 
			this->btnHit->BackColor = System::Drawing::Color::ForestGreen;
			this->btnHit->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnHit->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnHit->Location = System::Drawing::Point(495, 194);
			this->btnHit->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnHit->Name = L"btnHit";
			this->btnHit->Size = System::Drawing::Size(185, 78);
			this->btnHit->TabIndex = 1;
			this->btnHit->Text = L"HIT";
			this->btnHit->UseVisualStyleBackColor = false;
			this->btnHit->Click += gcnew System::EventHandler(this, &MyForm::btnHit_Click);
			// 
			// btnStay
			// 
			this->btnStay->BackColor = System::Drawing::Color::Firebrick;
			this->btnStay->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnStay->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnStay->Location = System::Drawing::Point(722, 194);
			this->btnStay->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnStay->Name = L"btnStay";
			this->btnStay->Size = System::Drawing::Size(185, 78);
			this->btnStay->TabIndex = 2;
			this->btnStay->Text = L"STAY";
			this->btnStay->UseVisualStyleBackColor = false;
			this->btnStay->Click += gcnew System::EventHandler(this, &MyForm::btnStay_Click);
			// 
			// lblHitOrStay
			// 
			this->lblHitOrStay->Anchor = System::Windows::Forms::AnchorStyles::Bottom;
			this->lblHitOrStay->AutoSize = true;
			this->lblHitOrStay->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->tableLayoutPanel1->SetColumnSpan(this->lblHitOrStay, 2);
			this->lblHitOrStay->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblHitOrStay->ForeColor = System::Drawing::Color::White;
			this->lblHitOrStay->Location = System::Drawing::Point(612, 165);
			this->lblHitOrStay->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->lblHitOrStay->Name = L"lblHitOrStay";
			this->lblHitOrStay->Size = System::Drawing::Size(233, 24);
			this->lblHitOrStay->TabIndex = 3;
			this->lblHitOrStay->Text = L"Do you want to Hit or Stay\?";
			// 
			// btnPlayAgain
			// 
			this->btnPlayAgain->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->btnPlayAgain->BackColor = System::Drawing::Color::Black;
			this->btnPlayAgain->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnPlayAgain->Location = System::Drawing::Point(521, 30);
			this->btnPlayAgain->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnPlayAgain->Name = L"btnPlayAgain";
			this->btnPlayAgain->Size = System::Drawing::Size(163, 61);
			this->btnPlayAgain->TabIndex = 4;
			this->btnPlayAgain->Text = L"Play Again!";
			this->btnPlayAgain->UseVisualStyleBackColor = false;
			this->btnPlayAgain->Click += gcnew System::EventHandler(this, &MyForm::btnPlayAgain_Click);
			// 
			// btnBet
			// 
			this->btnBet->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->btnBet->BackColor = System::Drawing::Color::ForestGreen;
			this->btnBet->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnBet->Location = System::Drawing::Point(315, 206);
			this->btnBet->Name = L"btnBet";
			this->btnBet->Size = System::Drawing::Size(116, 64);
			this->btnBet->TabIndex = 5;
			this->btnBet->Text = L"BET";
			this->btnBet->UseVisualStyleBackColor = false;
			this->btnBet->Click += gcnew System::EventHandler(this, &MyForm::btnBet_Click);
			// 
			// txtStatus
			// 
			this->txtStatus->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->txtStatus->BackColor = System::Drawing::Color::White;
			this->txtStatus->Location = System::Drawing::Point(719, 361);
			this->txtStatus->MinimumSize = System::Drawing::Size(20, 20);
			this->txtStatus->Multiline = true;
			this->txtStatus->Name = L"txtStatus";
			this->txtStatus->Size = System::Drawing::Size(246, 244);
			this->txtStatus->TabIndex = 6;
			// 
			// lblStatus
			// 
			this->lblStatus->Anchor = System::Windows::Forms::AnchorStyles::Bottom;
			this->lblStatus->AutoSize = true;
			this->lblStatus->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->lblStatus->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblStatus->Location = System::Drawing::Point(790, 338);
			this->lblStatus->Name = L"lblStatus";
			this->lblStatus->Size = System::Drawing::Size(104, 20);
			this->lblStatus->TabIndex = 7;
			this->lblStatus->Text = L"Game Status";
			// 
			// lblHeader
			// 
			this->lblHeader->AutoSize = true;
			this->lblHeader->BackColor = System::Drawing::Color::Transparent;
			this->tableLayoutPanel1->SetColumnSpan(this->lblHeader, 2);
			this->lblHeader->Dock = System::Windows::Forms::DockStyle::Fill;
			this->lblHeader->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->lblHeader->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblHeader->ForeColor = System::Drawing::Color::Snow;
			this->lblHeader->Location = System::Drawing::Point(16, 3);
			this->lblHeader->Name = L"lblHeader";
			this->lblHeader->Size = System::Drawing::Size(470, 115);
			this->lblHeader->TabIndex = 8;
			this->lblHeader->Text = L"Welcome to the C++ Blackjack Table!\r\nYou will begin with $1000.\r\nYou can view the"
				L" rules in the Menu above.";
			// 
			// lblForBet
			// 
			this->lblForBet->Anchor = System::Windows::Forms::AnchorStyles::Bottom;
			this->lblForBet->AutoSize = true;
			this->lblForBet->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->tableLayoutPanel1->SetColumnSpan(this->lblForBet, 2);
			this->lblForBet->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblForBet->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->lblForBet->Location = System::Drawing::Point(85, 141);
			this->lblForBet->Name = L"lblForBet";
			this->lblForBet->Size = System::Drawing::Size(332, 48);
			this->lblForBet->TabIndex = 9;
			this->lblForBet->Text = L"How much do you want to bet\? \r\nEnter an amount and click \"Bet\" to start";
			// 
			// txtBetAmount
			// 
			this->txtBetAmount->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Left | System::Windows::Forms::AnchorStyles::Right));
			this->txtBetAmount->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)),
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->txtBetAmount->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txtBetAmount->Location = System::Drawing::Point(16, 222);
			this->txtBetAmount->Name = L"txtBetAmount";
			this->txtBetAmount->Size = System::Drawing::Size(238, 32);
			this->txtBetAmount->TabIndex = 10;
			// 
			// txtPlayersHand
			// 
			this->txtPlayersHand->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->txtPlayersHand->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)),
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->txtPlayersHand->Location = System::Drawing::Point(16, 361);
			this->txtPlayersHand->MinimumSize = System::Drawing::Size(20, 20);
			this->txtPlayersHand->Multiline = true;
			this->txtPlayersHand->Name = L"txtPlayersHand";
			this->txtPlayersHand->Size = System::Drawing::Size(238, 244);
			this->txtPlayersHand->TabIndex = 11;
			// 
			// lblPlayersHand
			// 
			this->lblPlayersHand->Anchor = System::Windows::Forms::AnchorStyles::Bottom;
			this->lblPlayersHand->AutoSize = true;
			this->lblPlayersHand->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->lblPlayersHand->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblPlayersHand->Location = System::Drawing::Point(78, 338);
			this->lblPlayersHand->Name = L"lblPlayersHand";
			this->lblPlayersHand->Size = System::Drawing::Size(114, 20);
			this->lblPlayersHand->TabIndex = 12;
			this->lblPlayersHand->Text = L"Player\'s Hand: ";
			// 
			// lblDealersHand
			// 
			this->lblDealersHand->Anchor = System::Windows::Forms::AnchorStyles::Bottom;
			this->lblDealersHand->AutoSize = true;
			this->lblDealersHand->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->lblDealersHand->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDealersHand->Location = System::Drawing::Point(318, 338);
			this->lblDealersHand->Name = L"lblDealersHand";
			this->lblDealersHand->Size = System::Drawing::Size(110, 20);
			this->lblDealersHand->TabIndex = 13;
			this->lblDealersHand->Text = L"Dealer\'s Hand";
			// 
			// txtDealersHand
			// 
			this->txtDealersHand->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->txtDealersHand->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)),
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->txtDealersHand->Location = System::Drawing::Point(260, 361);
			this->txtDealersHand->MinimumSize = System::Drawing::Size(20, 20);
			this->txtDealersHand->Multiline = true;
			this->txtDealersHand->Name = L"txtDealersHand";
			this->txtDealersHand->Size = System::Drawing::Size(226, 244);
			this->txtDealersHand->TabIndex = 14;
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->AutoSize = true;
			this->tableLayoutPanel1->BackColor = System::Drawing::Color::Transparent;
			this->tableLayoutPanel1->ColumnCount = 4;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				51.3026F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				48.6974F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				227)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				251)));
			this->tableLayoutPanel1->Controls->Add(this->lblHeader, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->btnBet, 1, 2);
			this->tableLayoutPanel1->Controls->Add(this->lblPlayersHand, 0, 3);
			this->tableLayoutPanel1->Controls->Add(this->txtPlayersHand, 0, 4);
			this->tableLayoutPanel1->Controls->Add(this->lblDealersHand, 1, 3);
			this->tableLayoutPanel1->Controls->Add(this->txtDealersHand, 1, 4);
			this->tableLayoutPanel1->Controls->Add(this->btnStay, 3, 2);
			this->tableLayoutPanel1->Controls->Add(this->lblForBet, 0, 1);
			this->tableLayoutPanel1->Controls->Add(this->lblHitOrStay, 2, 1);
			this->tableLayoutPanel1->Controls->Add(this->txtStatus, 3, 4);
			this->tableLayoutPanel1->Controls->Add(this->lblStatus, 3, 3);
			this->tableLayoutPanel1->Controls->Add(this->txtBetAmount, 0, 2);
			this->tableLayoutPanel1->Controls->Add(this->btnHit, 2, 2);
			this->tableLayoutPanel1->Controls->Add(this->btnPlayAgain, 2, 0);
			this->tableLayoutPanel1->Controls->Add(this->btnQuit, 3, 0);
			this->tableLayoutPanel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel1->Location = System::Drawing::Point(0, 25);
			this->tableLayoutPanel1->Margin = System::Windows::Forms::Padding(15, 5, 15, 5);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->Padding = System::Windows::Forms::Padding(13, 3, 13, 3);
			this->tableLayoutPanel1->RowCount = 5;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 61.58192F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 38.41808F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 98)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 71)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 249)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(981, 611);
			this->tableLayoutPanel1->TabIndex = 15;
			// 
			// btnQuit
			// 
			this->btnQuit->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->btnQuit->BackColor = System::Drawing::Color::Black;
			this->btnQuit->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnQuit->Location = System::Drawing::Point(768, 29);
			this->btnQuit->Name = L"btnQuit";
			this->btnQuit->Size = System::Drawing::Size(148, 63);
			this->btnQuit->TabIndex = 15;
			this->btnQuit->Text = L"Quit\r\n";
			this->btnQuit->UseVisualStyleBackColor = false;
			this->btnQuit->Click += gcnew System::EventHandler(this, &MyForm::btnQuit_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(21)), static_cast<System::Int32>(static_cast<System::Byte>(81)),
				static_cast<System::Int32>(static_cast<System::Byte>(74)));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(981, 636);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Controls->Add(this->menuStrip1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->Name = L"MyForm";
			this->ShowIcon = false;
			this->Text = L"ChaviraCothrenWetmoreP6 Blackjack";
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->tableLayoutPanel1->ResumeLayout(false);
			this->tableLayoutPanel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		//EVENTS
		// event handlers for the five buttons
	private: System::Void btnBet_Click(System::Object^ sender, System::EventArgs^ e)
	{
		// The Bet button will initiate the game. It sets the bet into the class and if the return is false, displays a message in the Status box and the play does not continue. 
		int bet = Convert::ToInt32(txtBetAmount->Text);
		bool makeBet = game.SetBet(bet);
		if (!makeBet) {
			txtStatus->Text = "That bet is not valid. Please try again.";
			//A new bet must be entered and the BET button pressed again.
		}
		else {
			//If the return is true, it calls for the initial deal. 
			game.InitialDeal();
			//TW Show player hand
			txtPlayersHand->Text = gcnew String(game.ShowPlayerHand().c_str());
			//TW Show dealer hand
			txtDealersHand->Text = gcnew String(game.ShowDealersHand(true).c_str());
			//txtStatus->Text = gcnew String(game.ShowResults().c_str());
			//It checks for BlackJack and handles it appropriately.
			bool blackjack = game.IsBlackJack();
			if (blackjack) {
				//TODO something here??
				//TW Yes, a BlackJack on the initial deal means they get 1.5X their bet.
				//(Technically, if the dealer also gets BlackJack on the initial deal, it should be a tie but I don't think we're using those rules.)
				//bet *= 1.5;
				//TW Show the game results
				txtStatus->Text = gcnew String(game.ShowResults().c_str());
			}
			else
			{
				//If there is no BlackJack, the Bet group of(label, textbox and button) become not visible, and the Hit or Stay group become visible, so the play can continue.
				btnBet->Visible = false;
				lblForBet->Visible = false;
				txtBetAmount->Visible = false;
				lblHitOrStay->Visible = true;
				btnHit->Visible = true;
				btnStay->Visible = true;
			}
		}
	}
	private: System::Void btnHit_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//When the player clicks the Hit button, the event handler checks if the player may continue.
		if (game.PlayerContinues())
		{
			//If yes, the player hits and the new player hand is shown.
			game.PlayerHits();
			//print to results box
			txtPlayersHand->Text = gcnew String(game.ShowPlayerHand().c_str());
			//If the player is busted as a result, that is shown.
			if (game.PlayerBusted())
			{
				txtDealersHand->Text = gcnew String(game.ShowDealersHand(false).c_str());
				txtStatus->Text = gcnew String(game.ShowResults().c_str());
			}
			//TW If the player gets BlackJack, it calls game.ShowResults()
			if (game.IsBlackJack()) txtStatus->Text = gcnew String(game.ShowResults().c_str());
			//TODO ?The player can survey his hand and decide whether to hit again or stay.
		}
	}
	private: System::Void btnStay_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//When the player hits the stay button, the event handler checks if the dealer may continue.
		while (game.DealerContinues())
		{
			//If so, the new cards are shown and when the dealer must stop, the results of the game are shown.
			game.ShowDealersHand(true);
			txtDealersHand->Text = gcnew String(game.ShowDealersHand(true).c_str());
		}
		txtDealersHand->Text = gcnew String(game.ShowDealersHand(false).c_str());
		txtStatus->Text = gcnew String(game.ShowResults().c_str());
	}
	private: System::Void btnPlayAgain_Click(System::Object^ sender, System::EventArgs^ e)
	{
		//The PlayAgain button will re-initialize the Bet and Hit or Stay groups and clear the text Boxes.
		btnBet->Visible = true;
		lblForBet->Visible = true;
		txtBetAmount->Visible = true;
		lblHitOrStay->Visible = false;
		btnHit->Visible = false;
		btnStay->Visible = false;
		txtStatus->Clear();
		txtBetAmount->Clear();
		txtPlayersHand->Clear();
		txtDealersHand->Clear();
		game.ClearHands();
	}

	private: System::Void rulesOfTheGameMenu_Click(System::Object^ sender, System::EventArgs^ e)
	{
		String^ message = "C++ Blackjack Rules \r\nYou want the cards in your hand to have a value that is closer to 21 than that of the dealer, without going over 21. Any hand that goes over 21 is \"busted\", and automatically loses.\r\nAces are worth 1 point, numbered cards are worth their face value, and Face Cards are worth 10 points. Card suits do not matter.\r\nWhen it's your turn, choose \"Hit\" to be dealt another card, or \"Stay\" to keep your current hand.";
		MessageBox::Show(message);
	}
	private: System::Void btnQuit_Click(System::Object^ sender, System::EventArgs^ e) {
		game.EndGame();
		txtStatus->Text = "\r\n Thanks for playing!\r\n You can find a summary in the Log file";
	}
};
}