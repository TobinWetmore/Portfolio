//A. Noel Cothren
//acothren1@cnm.edu
//Program 6 - Blackjack Group Project

// Logger.cpp file

#include "Logger.h";

Logger::Logger()
{
	//create a filename
	FileName();

	//grab current time 
	Time();

	//open the file & if successful, start log
	output.open(filename);
	if (output.is_open()) {
		bLogOpen = true;
		//write the first line in the file
		output << "\r\n Welcome to C++ Blackjack. You're playing on " << timeNow << "\r\n";
	}
	else {
		bLogOpen = false;
	}

}

void Logger::FileName()
{
	// Creates the filename using dateTimeRightNow in this format: 
	// Log_month_day_year_hour_minute_second.txt or Log_dateTimeRightNow.txt
	auto now = chrono::system_clock::now();
	auto in_time_t = chrono::system_clock::to_time_t(now);
	stringstream ss;
	ss << put_time(localtime(&in_time_t), "%m_%d_%Y_%I.%M.%S");
	dateTimeStamp = ss.str();
	filename = "Log_" + dateTimeStamp + ".txt";
}

void Logger::Time() // gets time string for timeRightNow
{
	auto now = chrono::system_clock::now();
	auto in_time_t = chrono::system_clock::to_time_t(now);
	stringstream ss;
	ss << put_time(localtime(&in_time_t), "%m-%d-%Y at %I:%M:%S");
	timeNow = ss.str();
}
void Logger::StartLog(double initialBal) // writes the initial lines of the log file. A double is passed in.
{
	//write first lines
	//The first line of the log file is a time stamp. 

	output  << "Your balance is $" << fixed << setprecision(2) << initialBal << "\r\n";
}

void Logger::WriteLog(string s) //writes into the log file any time a game is completed.
{
	//grab string from game and add to output
	output << "Result: " << s;
}

void Logger::CloseLog(string s) //writes the message from the EndGame() function and closes the file.
{
	output << s;
	output.close();
}

bool Logger::IsLogOpen()
{
	return bLogOpen;
}

