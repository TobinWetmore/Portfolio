//A. Noel Cothren
//acothren1@cnm.edu
//Program 6 - Blackjack Group Project

// Card.h file

#ifndef CARD_H
#define CARD_H

#include <string>
#include <sstream>
using namespace std;


class Card
{
private:

	int iValue;  //numeric value corresponding to the card
	string value;  //�Ace� �2� through �9�, �Ten�, �Jack�, �Queen�, �King�
	string suit;  //�S�, �H�, �C�, �D�

public:
	// overloaded constructor: 
	Card(int n);
	//TW Added the default constructor so that errors don't happen when the hand class is instanciated
	Card();

	void SetIValue(int val) { iValue = val; }
	string GetValue() { return value; }
	int GetIValue() { return iValue; }
	string GetSuit() { return suit; }
};

#endif // !CARD_H