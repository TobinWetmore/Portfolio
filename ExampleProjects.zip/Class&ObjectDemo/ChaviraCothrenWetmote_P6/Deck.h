//Tobin Wetmore
//twetmore@cnm.edu
//Deck.h

#ifndef DECK
#define DECK

#include <random>
#include<chrono>
#include <array>
#include "Card.h"
using namespace std;

class Deck
{
private:
	//array of 52 cards
	array <int, 52>  cards;
	//0-51, index of the next card to be dealt
	int topCard;
	//Creates an object of the random engine
	default_random_engine engine;
public:
	//Initializer
	Deck();
	void Shuffle();
	int RandomCard();
	void Deal(Card& c);
};

#endif