//Tobin Wetmore
//twetmore@cnm.edu
//Game.h

#ifndef GAME
#define GAME

#include "Card.h"
#include "Deck.h"
#include "Hand.h"
#include "Logger.h"
#include <sstream>
using namespace std;

class Game
{
private:
	//There is one bet for each hand.
	int bet{ 0 };
	//This is the player�s money balance.
	double money{ 1000 };
	//keeps running totals for summary
	int wins{ 0 }, losses{ 0 }, ties{ 0 }, numberOfHands{ 0 };
	//The deck object  of cards
	Deck deck;
	//The player�s Hand object
	Hand playerHand;
	//The dealer�s Hand object
	Hand dealerHand;
	//The Logger object
	Logger log;

public:
	//Initializer
	Game();
	//sets the bet into the class, checks that the bet !< 0 and bet !>money.
	//If either case is true, the method returns false.
	//The event handler displays a message in the Status box and the play does not continue.
	//A new bet must be entered and the BET button pressed again.
	bool SetBet(int b);
	//Using a short for loop, deal both playerand dealer two cards.
	void InitialDeal();
	//returns playersHand.Show(false, false);
	string ShowPlayerHand() { return playerHand.Show(false,false); }
	//returns dealersHand.Show(true, hide)
	string ShowDealersHand(bool hide);
	//The player wins 1.5 *bet. returns playersHand.BlackJack()
	bool IsBlackJack();
	//returns playersHand.Busted()
	bool PlayerBusted() { return playerHand.Busted(); }
	//checks if the playersHand is bustedand if the playersHand is under(22) to return true.Else return false.
	bool PlayerContinues();
	//adds a Card to the playersHand
	void PlayerHits();
	//returns a description that starts with �Player wins : � and adds the amount of the betand tells how much money the player has now.
	//If the win was from a BlackJack, the win is 1.5 * bet.
	string PlayerWins();
	//checks if the dealer MustHit. If so, adds a Card to the dealersHandand returns true.Else returns false.
	bool DealerContinues();
	//Actually returns a description that starts with �Player loses : � and shows the amount of the betand tells how much money the player has now.
	string DealerWins();
	//returns a description starting with �tie�and tells how much money the player has now.
	string Tie();
	//A place holder, returns ��
	string NoResults() { return ""; }
	//determines the disposition of the gameand calls one of the methods above for the description.
	string ShowResults();
	//calls the ClearHand method for both hands.
	void ClearHands();
	bool  IsLogOpened() { return log.IsLogOpen(); }
	//creates the summary stringand calls the Logger�s CloseLog with the string as the argument.
	void EndGame();
};

#endif