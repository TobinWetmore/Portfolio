#include "Game.h"

Game::Game()
{
}

//Checks that the user inputs a valid bet, then sets the bet
bool Game::SetBet(int b)
{
	if (b > money)
	{
		return false;
	}
	else
	{
		bet = b;
		return true;
	}
}

//Deals two cards to the player and the dealer
void Game::InitialDeal()
{
	log.StartLog(money);
	for (int u = 0; u < 2; u++)
	{
		Card temp;
		deck.Deal(temp);
		playerHand.AddCard(temp);
	}
	for (int d = 0; d < 2; d++)
	{
		Card temp;
		deck.Deal(temp);
		dealerHand.AddCard(temp);
	}

	if (IsBlackJack())
	{
		bet *= 1.5;
	}
}

string Game::ShowDealersHand(bool hide)
{
	if (hide)
	{
		return dealerHand.Show(true, true);
	}
	else
	{
		return dealerHand.Show(false, false);
	}
}

//Checks if the user's hand is 21
bool Game::IsBlackJack()
{
	return playerHand.BlackJack();
}

//This function seems redundant, since Game.PlayerBusted() exists
bool Game::PlayerContinues()
{
	if (!playerHand.Busted())
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Adds the top card of the deck the user's hand
void Game::PlayerHits()
{
	Card temp;
	deck.Deal(temp);
	playerHand.AddCard(temp);
}

//Returns a formatted string if the player wins with nifty information
string Game::PlayerWins()
{
	stringstream ss;
	ss << "Player Wins. \r\n";
	ss << "Bet: $" << bet << "\r\n";
	if (IsBlackJack())
	{
		ss << "You got Black Jack!\r\n";
	}
	money += bet;
	ss << "Balance: $" << money << "\r\n";
	log.WriteLog(ss.str());
	return ss.str();
}

bool Game::DealerContinues()
{
	if (dealerHand.MustHit())
	{
		Card temp;
		deck.Deal(temp);
		dealerHand.AddCard(temp);
		return true;
	}
	else
	{
		return false;
	}
}

//Returns a formatted string if the player loses with nifty information
string Game::DealerWins()
{

	stringstream ss;
	ss << "Player loses. \r\n";
	ss << "Bet: $" << bet << "\r\n";
	money -= bet;
	ss << "Balance: $" << money << "\r\n";
	log.WriteLog(ss.str());
	return ss.str();
}

//Returns a formatted string if the initial deal hands are both BlackJack
string Game::Tie()
{
	stringstream ss;
	ss << "Tie. \r\n";
	ss << "Balance: $" << money << "\r\n";
	log.WriteLog(ss.str());
	return ss.str();
}

//This function determines who wins and returns the approriate string to say so
string Game::ShowResults()
{
	if (dealerHand.Busted() && playerHand.Busted())
	{
		return Tie();
	}
	else if (playerHand.Busted())
	{
		return DealerWins();
	}
	else if (dealerHand.Busted())
	{
		return PlayerWins();
	}
	else if (dealerHand.BestScore() < playerHand.BestScore())
	{
		return PlayerWins();
	}
	else if (dealerHand.BestScore() > playerHand.BestScore())
	{
		return DealerWins();
	}
	else if (dealerHand.BestScore() == playerHand.BestScore())
	{
		return PlayerWins();
	}
	else
	{
		log.WriteLog(NoResults());
		return NoResults();
	}
}

//Empties the user's and dealer's hands
void Game::ClearHands()
{
	playerHand.ClearHand();
	dealerHand.ClearHand();
}

//Closes the log and gives a formatted string of nifty placeholder information
void Game::EndGame()
{
	stringstream ss;
	ss << "The game is over. You have $" << money << "\nGoodbye!";
	log.CloseLog(ss.str());
}
