//A. Noel Cothren
//acothren1@cnm.edu
//Program 6 - Blackjack Group Project

// Logger.h file
//The Logger class receives strings from the BlackJack Game and writes them into the log file. 

#ifndef LOGGER_H
#define LOGGER_H

#include <chrono>
#include <ctime>
#include <random>
#include <sstream>
#include <fstream>
#include <iomanip>

using namespace std;

class Logger
{
private:
	string filename;
	string timeNow;
	string dateTimeStamp;
	bool bLogOpen;
	ofstream output; //to be written into repeatedly
	void Time();  // gets time string for timeNow
	void FileName();  //Creates the filename using dateTimeRightNow in this format: Log_month_day_year_hour_minute_second.txt or Log_ dateTimeRightNow.txt
public:
	Logger();
	void StartLog(double initialBal);// writes the initial lines of the log file.A double is passed in.
	void WriteLog(string s);//writes into the log file any time a game is completed.
	void CloseLog(string s); //writes the message from the EndGame() function and closes the file.
	bool IsLogOpen();// returns bLogOpen so the log success can be checked by the Game class.
};

#endif