//Tobin Wetmore
//twetmore@cnm.edu
//Hand.cpp

#include "Hand.h"

Hand::Hand()
{
}

//Adds a card to the hand
void Hand::AddCard(Card c)
{
	//checks to see if a card can be added
	if (numCards < MAX_CARDS)
	{
		//adds the card
		cards[numCards] = c;
		numCards++;
	}
}

//Required by the spec, even though both booleans mean the same thing.
string Hand::Show(bool isdealer, bool hideFirstCard)
{
	stringstream ss;
	//hides the first card if it's the dealer's hand
	if (isdealer)
	{
		ss << "Hidden\r\n";
		for (int i = 1; i < numCards; i++)
		{
			ss << cards[i].GetValue() << " of " << cards[i].GetSuit() << "\r\n";
		}
	}
	else
	{
		for (int i = 0; i < numCards; i++)
		{
			ss << cards[i].GetValue() << " of " << cards[i].GetSuit() << "\r\n";
		}
	}
	return ss.str();
}

//Overloaded function that doesn't include redundant things required by the spec
string Hand::Show(bool isdealer)
{
	stringstream ss;
	//hides the first card if it's the dealer's hand
	if (isdealer)
	{
		ss << "Hidden\r\n";
		for (int i = 1; i < numCards; i++)
		{
			ss << cards[i].GetValue() << " of " << cards[i].GetSuit() << "\r\n";
		}
	}
	else
	{
		for (int i = 0; i < numCards; i++)
		{
			ss << cards[i].GetValue() << " of " << cards[i].GetSuit() << "\r\n";
		}
	}
	return ss.str();
}

//Adds up the value of the hand and detirmines if it's blackjack
bool Hand::BlackJack()
{
	if (BestScore() == BLACKJACK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Check to see if the hand is under a passed int. Uses the DEALER_TARGET constant
bool Hand::Under(int n)
{
	if (BestScore() < n)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Figures out the best possible score for the hand
int Hand::BestScore()
{
	//The value of the hand
	int handVal{ 0 };
	//The number of Ace cards in the hand
	int numAces{ 0 };

	//Figures out the number of aces in the hand
	for (int i = 0; i < numCards; i++)
	{
		int valTemp = cards[i].GetIValue();
		if (valTemp == 1)
		{
			numAces++;
		}
	}

	//Finds the initial value of the hand
	for (int i = 0; i < numCards; i++)
	{
		handVal += cards[i].GetIValue();
	}

	//Adds value to the aces if it won't bust the hand
	while (numAces > 0)
	{
		if (handVal + ACE <= BLACKJACK)
		{
			handVal += ACE;
		}
		else
		{
			break;
		}
	}

	return handVal;
}

//Logic for the dealers had that determines if the dealer has to hit or stay
bool Hand::MustHit()
{
	if (Under(DEALER_TARGET))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Calculates if the hand is over the limit for BlackJack (21)
bool Hand::Busted()
{
	if (BestScore() > BLACKJACK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Empties the hand
void Hand::ClearHand()
{
	cards.empty();
	showHand = "";
	numCards = 0;

}
