//Tobin Wetmore
//twetmore@cnm.edu
//Deck.cpp

#include "Deck.h"

Deck::Deck()
{
	//initialize values of carda array from 0-51
	for (int i = 0; i < cards.size(); i++)
	{
		cards[i] = i;
	}
	//Seed the engine
	engine.seed(chrono::system_clock::now().time_since_epoch().count());
	Shuffle();
}

void Deck::Shuffle()
{
	for (int i = 0; i < cards.size(); i++)
	{
		int temp = cards[i];
		int rando = RandomCard();
		cards[i] = cards[rando];
		cards[rando] = temp;
	}

	topCard = 0;
}

int Deck::RandomCard()
{
	uniform_int_distribution<unsigned int> randomInt(0, 51);
	int r = randomInt(engine);
	return r;
}

void Deck::Deal(Card& c)
{
	//check to see if the top card is greater than 34
	if (topCard > 34)
	{
		Shuffle();
	}
	//get the int value of cards[topCard]
	int card = cards[topCard];
	//create a card object passing that int
	Card temp(card);
	//set the a new card temp equal to c
	c = temp;
	//increment topCard
	topCard++;
}
