//A Noel Cothren
//acothren1@cnm.edu
//Program 6 Blackjack Group Project

// file = MyForm.cpp

#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;


[STAThread]
void Main()
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	ChaviraCothrenWetmoteP6::MyForm form;
	Application::Run(% form);
}
