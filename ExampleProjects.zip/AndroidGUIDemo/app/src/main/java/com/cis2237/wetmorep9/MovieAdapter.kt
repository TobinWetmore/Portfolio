package com.cis2237.wetmorep9

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.cis2237.wetmorep9.model.Movie

class MovieAdapter(private val clickListener: MovieClickListener) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>()  {
    //List of movies
    private val movies = mutableListOf<Movie>()

    //Pass the poster and title to the viewHolder
    class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageUrl = "https://image.tmdb.org/t/p/w185/"
        private val titleText: TextView by lazy { itemView.findViewById(R.id.movieTitle) }
        private val poster: ImageView by lazy { itemView.findViewById(R.id.moviePoster) }

        fun bind(movie: Movie) {
            titleText.text = movie.title

            //Glide loads the image
            Glide.with(itemView.context)
                .load("$imageUrl${movie.poster_path}")
                .placeholder(R.mipmap.ic_launcher)
                .fitCenter()
                .into(poster)
        }
    }

    interface MovieClickListener{ fun onMovieClick(movie: Movie) }

    //Inflate the view and pass it to the MovieViewHolder constructor. Return the MovieViewHolder
    //object.
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        //TODO: Figure out what E is I'm given 4 different import options that all seem math related
        val view = LayoutInflater.from(parent.context).inflate(R.layout.view_movie_item, parent, false)
        return MovieViewHolder(view)
    }

    //Get the size of movies. No logic is required because it isn't nullable and it will always have
    //a size.
    override fun getItemCount(): Int { return movies.size }

    //Bind onClickListeners to the itemViews
    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movies[position]
        holder.itemView.setOnClickListener { clickListener.onMovieClick(movie) }
        holder.bind(movie)
    }

    //Add movies the the list
    fun addMovies(movieList: List<Movie>){
        movies.addAll(movieList)
        notifyItemRangeInserted(0, movieList.size)
    }
}