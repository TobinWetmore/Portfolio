package com.cis2237.wetmorep9.api

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.cis2237.wetmorep9.model.Movie

class MovieRepository(private val movieService: MovieService) {
    //My API key
    private val apiKey = "33a5c8440e13e6b9e28976f59b605dee"
    //To hold the movies
    private val movieLiveData = MutableLiveData<List<Movie>>()
    //To hold the errors (but hopefully not)
    private val errorLiveData = MutableLiveData<String>()

    //Getters for the movies and errors
    val movies: LiveData<List<Movie>> get() = movieLiveData
    val error: LiveData<String> get() = errorLiveData

    //Get the movies from The Movie Database
    suspend fun fetchMovies() {
        try {
            val popularMovies = movieService.getPopularMovies(apiKey)
            movieLiveData.postValue(popularMovies.results)
        } catch (exception: Exception) {
            errorLiveData.postValue("An error occurred: ${exception.message}")
        }
    }
}