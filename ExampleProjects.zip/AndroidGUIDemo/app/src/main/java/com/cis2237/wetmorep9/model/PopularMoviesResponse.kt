package com.cis2237.wetmorep9.model

//Holds data received from The Movie Database after fetching.
data class PopularMoviesResponse(
    val page: Int,
    val results : List<Movie>
)
