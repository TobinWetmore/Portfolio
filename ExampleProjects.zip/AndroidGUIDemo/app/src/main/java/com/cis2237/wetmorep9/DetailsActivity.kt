package com.cis2237.wetmorep9

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import com.bumptech.glide.Glide
import com.cis2237.wetmorep9.databinding.ActivityDetailsBinding

class DetailsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_RELEASE = "release"
        const val EXTRA_OVERVIEW = "overview"
        const val EXTRA_POSTER = "poster"
        const val IMAGE_URL = "https://image.tmdb.org/t/p/w185/"
    }

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Initializes the fields in the activity
        val titleText: TextView = findViewById(R.id.detailTitle)
        val releaseText: TextView = findViewById(R.id.detailRelease)
        val overviewText: TextView = findViewById(R.id.detailOverview)
        val poster: ImageView = findViewById(R.id.detailPoster)

        //Get the passed data
        val extras = intent.extras

        //Set the passed data into the fields
        titleText.text = extras?.getString(EXTRA_TITLE).orEmpty()
        releaseText.text = extras?.getString(EXTRA_RELEASE).orEmpty().take(4)

        overviewText.text = getString(R.string.movie_overview, extras?.getString(EXTRA_OVERVIEW).orEmpty())

        val posterPath = extras?.getString(EXTRA_POSTER).orEmpty()
        Glide.with(this@DetailsActivity)
            .load("$IMAGE_URL$posterPath")
            .placeholder(R.mipmap.ic_launcher)
            .fitCenter()
            .into(poster)
    }
}