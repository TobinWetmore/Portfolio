﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SprocketOrderForm
{
    internal class Address
    {
        //Street address of Customer
        public string Street { get; set; }
        //City of Customer
        public string City { get; set; }
        //State Customer lives in
        public string State { get; set; }
        //Customer Zip Code
        public int ZipCode { get; set; }

        //Formats the address
        public override string ToString()
        {
            return Street + ", " + City + ", " + State + ", " + ZipCode.ToString();
        }
    }
}
