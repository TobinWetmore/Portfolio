﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SprocketOrderForm
{
    /// <summary>
    /// Interaction logic for SprocketForm.xaml
    /// </summary>
    public partial class SprocketForm : Window
    {
        //Reports if the window is closed to call the update function in the MainWindow
        public bool IsClosed { get; private set; }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            IsClosed = true;
        }
        public SprocketForm()
        {
            InitializeComponent();
        }

        //passes information to the MainWindow through a static class
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (cmbbxType.Text == "Steel")
            {
                MainWindow.addSproc(Int32.Parse(txtbxItemID.Text), Int32.Parse(txtbxTeethNum.Text), Int32.Parse(txtbxNumItems.Text), 's');
            }
            else if (cmbbxType.Text == "Aluminum")
            {
                MainWindow.addSproc(Int32.Parse(txtbxItemID.Text), Int32.Parse(txtbxTeethNum.Text), Int32.Parse(txtbxNumItems.Text), 'a');
            }
            else
            {
                MainWindow.addSproc(Int32.Parse(txtbxItemID.Text), Int32.Parse(txtbxTeethNum.Text), Int32.Parse(txtbxNumItems.Text), 'p');
            }
        }

        //closes the window
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
