﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SprocketOrderForm
{
    internal class SprocketOrder
    {
        //List of sprockets in the order
        private List<Sprocket> sprockets;
        public List<Sprocket> Sprockets { get { return sprockets; } }
        //Customer Address
        public Address Address { get; set; }
        //Customer Name
        public string Name { get; set; }

        //total price of the order
        private decimal totalPrice;
        public decimal TotalPrice { get { Calc();  return totalPrice; } }

        //constructor
        public SprocketOrder()
        {
            sprockets = new List<Sprocket>();
            Name = "";
        }

        //overloaded constructor
        public SprocketOrder(List<Sprocket> sprocks,Address add, string nm, decimal tp)
        {
            sprockets = sprocks;
            Address = add;
            Name = nm;
            Calc();
        }

        //calculates the cost of the whole order
        private void Calc()
        {
            decimal price = 0;
            foreach (Sprocket sprocket in sprockets)
            {
                price += sprocket.Price;
            }
            totalPrice = price;
        }

        //adds sprockets to the order
        public void addSprocket(Sprocket s)
        {
            sprockets.Add(s);
            Calc();
        }

        //removes sprockets from the order
        public void removeSprocket(Sprocket s)
        {
            sprockets.Remove(s);
        }

        //Formats the order as a string with the Customer Name, Address or Local Pickup, and list of the sprockets
        public override string ToString()
        {
            //list of sprockets
            string sprocks = "";
            foreach (Sprocket sprocket in sprockets)
            {
                sprocks += sprocket.ToString() + "\n";
            }
            //I can null the street, not necessarily the whole address, so I have this as my parameter
            if(Address.Street != null)
            {
                return "Name: " + Name + "\nAddress: " + Address.ToString() + "\n\n\n" + sprocks + "Total Price: " + TotalPrice;
            }
            else
            {

                return "Name: " + Name + "\nLocal pickup" + "\n\n\n" + sprocks + "Total Price: " + TotalPrice;
            }
        }
    }
}
