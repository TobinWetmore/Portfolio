﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SprocketOrderForm
{
    abstract class Sprocket
    {
        //Number of sprockets in order item
        protected int numItems;
        protected int NumItems { get { return numItems; } set { numItems = value; } }

        //Number of teeth on the sprocket
        protected int numTeeth;
        protected int NumTeeth { get { return numTeeth; } set { numTeeth = value; } }

        //Cost of the order item
        public abstract decimal Price { get; }

        //ID for a given type of sprocket
        protected int ItemID { get; }

        //Calculates the cost of the order item
        protected abstract void Calc();

        //number of the order item. The spec mentioned it, but didn't explicitly call for it. Increments every time a new sprocket is made
        private int orderNum = 0;
        
        //Constructor
        public Sprocket()
        {
            ItemID = 0;
            numItems = 1;
            numTeeth = 1;
            orderNum++;
        }

        //Overloaded Constructor
        public Sprocket(int ID, int itemNum, int teethNum)
        {
            NumItems = itemNum;
            NumTeeth = teethNum;
            ItemID = ID;
            Calc();
            orderNum++;
        }

        //Formats the order item
        public override string ToString()
        {
            return "Order Number: " + orderNum + " Item ID: " + ItemID + " Number of Teeth: " + numTeeth + " Quantity: " + numItems;
        }
    }
}
