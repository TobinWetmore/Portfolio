﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SprocketOrderForm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static SprocketOrder spo;

        public MainWindow()
        {
            InitializeComponent();
            spo = new SprocketOrder();
        }

        private void chkbxLocal_Checked(object sender, RoutedEventArgs e)
        {
            lblAddress.Visibility = Visibility.Hidden;
            lblStreet.Visibility = Visibility.Hidden;
            txtbxStreet.Visibility = Visibility.Hidden;
            lblCity.Visibility = Visibility.Hidden;
            txtbxCity.Visibility = Visibility.Hidden;
            lblState.Visibility = Visibility.Hidden;
            txtbxState.Visibility = Visibility.Hidden;
            lblZipCode.Visibility = Visibility.Hidden;
            txtbxZipCode.Visibility = Visibility.Hidden;
            spo.Address = null;
        }

        private void chkbxLocal_Unchecked(object sender, RoutedEventArgs e)
        {
            lblAddress.Visibility = Visibility.Visible;
            lblStreet.Visibility = Visibility.Visible;
            txtbxStreet.Visibility = Visibility.Visible;
            lblCity.Visibility = Visibility.Visible;
            txtbxCity.Visibility = Visibility.Visible;
            lblState.Visibility = Visibility.Visible;
            txtbxState.Visibility = Visibility.Visible;
            lblZipCode.Visibility = Visibility.Visible;
            txtbxZipCode.Visibility = Visibility.Visible;
        }

        //opens the SprocketForm
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            SprocketForm frm = new SprocketForm();
            frm.ShowDialog();
            //Updates the listbox when the sprocket form closes
            if (frm.IsClosed)
            {
                updateListBox();
            }
        }

        //removes an order item
        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Confirm", "Are you sure you want to remove the selected item?", MessageBoxButton.YesNo);
            if(result == MessageBoxResult.Yes)
            {
                Sprocket tmp = lstbxOrder.SelectedItem as Sprocket;
                spo.removeSprocket(tmp);
                updateListBox();
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            if (saveFile.ShowDialog() == true)
            {
                using (StreamWriter file = new StreamWriter(saveFile.OpenFile()))
                {
                    file.WriteLine(spo.ToString());
                }
            }
        }

        public static void addSproc(int id, int teeth, int num, char material)
        {
            Sprocket sp;
            if (material == 's')
            {
                sp = new SteelSprocket(id, teeth, num);
            }
            else if (material == 'a')
            {
                sp = new AluminumSprocket(id, teeth, num);
            }
            else
            {
                sp = new PlasticSprocket(id, teeth, num);
            }
            spo.addSprocket(sp);
        }

        //Updates the listbox since I can't do it from the static class
        private void updateListBox()
        {
            lstbxOrder.Items.Clear();
            foreach (Sprocket sprocket in spo.Sprockets)
            {
                lstbxOrder.Items.Add(sprocket);
            }
            if(chkbxLocal.IsChecked == false)
            {
                spo.Address.Street = txtbxStreet.Text;
                spo.Address.City = txtbxCity.Text;
                spo.Address.State = txtbxState.Text;
                spo.Address.ZipCode = Int32.Parse(txtbxZipCode.Text);
            }
            else if(spo.Address != null)
            {
                spo.Address.Street = null; 
            }
            spo.Name = txtbxCSName.Text;
        }
    }
}