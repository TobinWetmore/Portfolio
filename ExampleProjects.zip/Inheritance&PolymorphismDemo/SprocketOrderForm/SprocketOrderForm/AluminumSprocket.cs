﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SprocketOrderForm
{
    internal class AluminumSprocket : Sprocket
    {
        //Cost of this order item
        private decimal price;
        public override decimal Price { get { return price; } }
        //Constructor
        public AluminumSprocket(int id, int itemNum, int teethNum) : base(id, itemNum, teethNum) { }
        //Formats order item
        public override string ToString()
        {
            return base.ToString() + " Material: Aluminum Order Price: " + Price.ToString("C0");
        }

        //Calculates costs of order item
        protected override void Calc()
        {
            //4 cents per tooth
            price = (decimal)(numItems * numTeeth * 0.04);
        }
    }
}
