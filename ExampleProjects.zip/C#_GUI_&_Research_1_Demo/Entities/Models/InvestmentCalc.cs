﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
	public class InvestmentCalc
	{
		//The amount accrued over the life of the investment.
		public double TotalAmount { get; private set; }

		/*
		 * I wrote this error handling stuff before you showed us how. I kinda like it so I kept it. 
		 * I'll throw in the proper way later.
		 */

		//Notify users of any wrong input for the compund variable.
		public string compoundErr { get; private set; }
		//Notify users of any wrong input for the interest variable.
		public string interestErr { get; private set; }
		//Notify users of any wrong input for the principle variable.
		public string principleErr { get; private set; }
		//Notify users of any wrong input for the year variable.
		public string yearErr { get; private set; }

		//How often the interest is compounded.
		private int comoundsPerYear = 1;
		public int CompoundsPerYear
		{
			get { return comoundsPerYear; }
			set
			{
				if (value >= 1 && value <= 24)
				{
					//set the value
					comoundsPerYear = value;
					//Calculate the new investment with the new data
					Calc();
					//Clear any compounding errors
					compoundErr = "";
				}
				else
				{
					compoundErr = "The interest must compound between 1 and 24 times per year.";
				}
			}
		}

		//The interest rate for the investment
		private double interestRate = 0.01;
		public double InterestRate
		{
			get { return interestRate; }
			set
			{
				if (value >= 0 && value <= 1)
				{
					//set the value
					interestRate = value;
					//Calculate the new investment with the new data
					Calc();
					//Clear any interest errors.
					interestErr = "";
				}
				else
				{
					interestErr = "The interest rate must be between 0.00 (0%) and 1.00 (100%).";
				}
			}
		}

		//The amount invested.
		private double principle = 1;
		public double Principle
		{
			get { return principle; }
			set
			{
				if (value > 0 && value <= Double.MaxValue)
				{
					//set the value
					principle = value;
					//Calculate the new investment with the new data
					Calc();
					//Clear any principle errors.
					principleErr = "";
				}
				else
				{
					principleErr = "The principle must be between 0 and " + Double.MaxValue.ToString() + ".";
				}
			}
		}

		//The length of growth to calculate.
		private int years = 1;
		public int Years
		{
			get { return years; }
			set
			{
				if (value >= 1 && value <= 30)
				{
					//set the value
					years = value;
					//Calculate the new investment with the new data
					Calc();
					//clear any year errors
					yearErr = "";
				}
				else
				{
					yearErr = "The term must be between 1 and 30 years.";
				}
			}
		}

		//Default Constructor
		public InvestmentCalc()
		{
			comoundsPerYear = 1;
			interestRate = 0.01;
			principle = 1;
			years = 1;
		}

		//Overloaded Constructor
		public InvestmentCalc(int compundsPerYear, double interestRate, double principle, int years)
		{
			CompoundsPerYear = compundsPerYear;
			InterestRate = interestRate;
			Principle = principle;
			Years = years;
			Calc();
		}

		//Calculate the TotalAmount.
		private void Calc()
		{
			/*
             * The equation being employed:
             * TotalAmount = principle * (1 + interestRate / compoundsPerYear) ^ (compoundsPerYear * years)
             */
			//A temporary variable to hold the first part of the equation.
			double temp = 1 + (interestRate / comoundsPerYear);
			//A temporary variable to hold the exponent part of the equation.
			int exponentTemp = comoundsPerYear * years;
			//Apply the exponent to the portion in parenthases.
			double temp2 = Math.Pow(temp, exponentTemp);
			//Multiply everything by the principle to get the total vaule.
			TotalAmount = principle * temp2;
		}
	}
}
