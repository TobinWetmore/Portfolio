﻿using System.ComponentModel.DataAnnotations;

namespace Entities.Models
{
    public class Asset
    {
		//Primary Key
        public Guid Id { get; set; } = Guid.Empty;

		//Name of the asset
		[Required]
		[MinLength(1, ErrorMessage = "Title must contain 1 character.")]
		public string? Title { get; set; }

		//When the asset was acquired.
		[Required]
		//Restrict to present or older
		private DateTime? acquisitionDate;
		public DateTime? AcquisitionDate 
		{ 
			get { return acquisitionDate; }
			set 
			{ 
				if(value > DateTime.Now)
				{
					acquisitionDate = DateTime.Now;
				}
				else
				{
                    acquisitionDate = value;
				}
				if (initialValue != null && depreciationRate != null && salvageValue != null)
				{
					Calc();
				}
			} 
		}

		//How quickly the asset depreciates (dollars per year).
		[Required]
        //TODO: Figure out why Range doesn't work
        [Range(0.01,double.MaxValue,ErrorMessage = "Depreciation Rate must be greater than one cent per year.")]
		public double? depreciationRate;
		public double? DepreciationRate 
		{ 
			get { return depreciationRate; }
			set
			{ 
				if(value <= 0)
				{
					depreciationRate = 0.01;
				}
				else
				{
					depreciationRate = value;
				}
				if (initialValue != null && salvageValue != null && acquisitionDate != null)
				{
					Calc();
				}
			}
		}

		//What the asset was worth new.
		[Required]
        //TODO: Figure out why Range doesn't work
        [Range(0.01, double.MaxValue, ErrorMessage = "Initial Value must be greater than one.")]
        public double? initialValue;
		public double? InitialValue 
		{ 
			get { return initialValue; } 
			set
			{
				if (value <= 0)
				{
					initialValue = 0.01;
				}
				else
				{
					initialValue = value;
				}
				if (salvageValue != null && depreciationRate != null && acquisitionDate != null)
				{
					Calc();
				}
			}
		}

		//The minimum possible value of the asset.
		[Required]
        //TODO: Figure out why Range doesn't work
        [Range(0, double.MaxValue, ErrorMessage = "Salvage Value must be greater than zero.")]
        public double? salvageValue;
		public double? SalvageValue 
		{ 
			get { return salvageValue; }
			set
			{
				if (value < 0)
				{
					salvageValue = 0;
				}
				else
				{
					salvageValue = value;
				}
				if (initialValue != null && depreciationRate != null && acquisitionDate != null)
				{
					Calc();
				}
			}
		}

		//The current value of the asset.
		public double? CurrentValue { get; private set; }

        private void Calc()
        {
            double? currentValue;
            //TimeSpan only gives you days or smaller, the hateful whelp. Divide by 365.25 to crudely convert it to years.
            //TODO: Make this more precise and less crap.
            double? assetAge = DateTime.Now.Subtract((DateTime)this.AcquisitionDate).Days / 365.25;

            //Calculate the current value
            currentValue = this.InitialValue - (assetAge * this.DepreciationRate);
            //if the current value is less than the salvage value, set it to that.
            if (currentValue < this.SalvageValue)
            {
                this.CurrentValue = (double)Math.Round((decimal)this.SalvageValue, 2);
			}
            //Otherwise, set the current value.
            else
            {
                this.CurrentValue = (double)Math.Round((decimal)currentValue, 2);
			}
        }

        //After writing this, I realized I could do this while writing the graph more easily by just subtracting the depreciation rate
        //for every year. Oh well, this is less of a hack job. It's good to do things properly.
        //Calculates the depreciation of the asset at a given time.
        public double? Calc(DateTime time)
        {
            double? currentValue;
			//TimeSpan only gives you days or smaller, the vile shrew. Divide by 365.25 to crudely convert it to years.
			//TODO: Make this more precise and less crap.
			DateTime temp = (DateTime)this.AcquisitionDate;
            double? assetAge = time.Subtract(temp).Days / 365.25;

            //Calculate the current value
            currentValue = this.InitialValue - (assetAge * this.DepreciationRate);
            //if the current value is less than the salvage value, return that.
            if (currentValue < this.SalvageValue)
            {
				//Round it to two decimal places. So much casing...
                return (double)Math.Round((decimal)this.SalvageValue,2);
            }
            //Otherwise, return the current value.
            else
			{
				//Round it to two decimal places. So much casing...
				return (double)Math.Round((decimal)currentValue, 2);
			}
        }
    }
}
