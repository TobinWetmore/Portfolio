﻿using Entities.Models;

namespace Entities.Interfaces
{
    public interface IAssetDAL
    {
        public Task<List<Asset>> GetAllAsync();
        public Task<Asset?> GetAssetAsync(Guid id);
        public Task AddAsync(Asset badge);
        public Task UpdateAsync(Asset? badge);
        public Task DeleteAsync(Guid id);
    }
}
