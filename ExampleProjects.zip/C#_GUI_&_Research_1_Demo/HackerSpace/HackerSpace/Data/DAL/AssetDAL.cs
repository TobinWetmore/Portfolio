﻿using Entities.Interfaces;
using Entities.Models;
using Microsoft.EntityFrameworkCore;

namespace HackerSpace.Data.DAL
{
    public class AssetDAL : IAssetDAL

    {
        private readonly ApplicationDbContext _context;

        public AssetDAL(ApplicationDbContext context)
        {
            _context = context;
        }

        //Get all
        public async Task<List<Asset>> GetAllAsync()
        {
            return await _context.Assets.ToListAsync();
        }
        //Add Item
        public async Task AddAsync(Asset asset)
        {
            _context.Assets.Add(asset);
            await _context.SaveChangesAsync();
        }

        //Delete Item
        public async Task DeleteAsync(Guid id)
        {
            var existingAsset = await _context.Assets.Where(a => a.Id == id).FirstOrDefaultAsync();
            if (existingAsset != null)
            {
                _context.Remove(existingAsset);
            }
            await _context.SaveChangesAsync();
        }

		//Get item
		public async Task<Asset?> GetAssetAsync(Guid id)
		{
			var existingAsset = await _context.Assets.Where(a => a.Id == id).FirstOrDefaultAsync();
			return existingAsset;
		}

		//Update Item
		public async Task UpdateAsync(Asset? asset)
		{
			//find the original in the list
			var existingAsset = await _context.Assets.Where(b => b.Id == asset!.Id).FirstOrDefaultAsync();

			if (existingAsset != null)
			{
				//assign the new entity properties into the old one
				existingAsset.Title = asset?.Title;
				existingAsset.AcquisitionDate = (asset?.AcquisitionDate);
				existingAsset.InitialValue = asset?.InitialValue;
				existingAsset.SalvageValue = asset?.SalvageValue;
				existingAsset.DepreciationRate = asset?.DepreciationRate;
				//save changes
				await _context.SaveChangesAsync();
			}
			else
			{
                //TODO: Handle badge not found error
            }
            await _context.SaveChangesAsync();
         }
	}
}
