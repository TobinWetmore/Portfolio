﻿namespace LogoShop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrderNumber = new System.Windows.Forms.Label();
            this.lblNumberOfItems = new System.Windows.Forms.Label();
            this.grpbxItemType = new System.Windows.Forms.GroupBox();
            this.rdbtnPen = new System.Windows.Forms.RadioButton();
            this.rdbtnMug = new System.Windows.Forms.RadioButton();
            this.rdbtnUSB = new System.Windows.Forms.RadioButton();
            this.txtbxOrderNumber = new System.Windows.Forms.TextBox();
            this.txtbxNumberOfItems = new System.Windows.Forms.TextBox();
            this.lblTextInput = new System.Windows.Forms.Label();
            this.txtbxUserText = new System.Windows.Forms.TextBox();
            this.lblNumberOfColors = new System.Windows.Forms.Label();
            this.txtbxNumberOfColors = new System.Windows.Forms.TextBox();
            this.chkbxLogo = new System.Windows.Forms.CheckBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtbxResults = new System.Windows.Forms.TextBox();
            this.grpbxItemType.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblOrderNumber
            // 
            this.lblOrderNumber.AutoSize = true;
            this.lblOrderNumber.Location = new System.Drawing.Point(20, 34);
            this.lblOrderNumber.Name = "lblOrderNumber";
            this.lblOrderNumber.Size = new System.Drawing.Size(132, 25);
            this.lblOrderNumber.TabIndex = 0;
            this.lblOrderNumber.Text = "Order Number:";
            // 
            // lblNumberOfItems
            // 
            this.lblNumberOfItems.AutoSize = true;
            this.lblNumberOfItems.Location = new System.Drawing.Point(20, 71);
            this.lblNumberOfItems.Name = "lblNumberOfItems";
            this.lblNumberOfItems.Size = new System.Drawing.Size(152, 25);
            this.lblNumberOfItems.TabIndex = 1;
            this.lblNumberOfItems.Text = "Number of Items:";
            this.lblNumberOfItems.Click += new System.EventHandler(this.lblNumberOfItems_Click);
            // 
            // grpbxItemType
            // 
            this.grpbxItemType.Controls.Add(this.rdbtnPen);
            this.grpbxItemType.Controls.Add(this.rdbtnMug);
            this.grpbxItemType.Controls.Add(this.rdbtnUSB);
            this.grpbxItemType.Location = new System.Drawing.Point(678, 34);
            this.grpbxItemType.Name = "grpbxItemType";
            this.grpbxItemType.Size = new System.Drawing.Size(110, 187);
            this.grpbxItemType.TabIndex = 2;
            this.grpbxItemType.TabStop = false;
            this.grpbxItemType.Text = "ItemType";
            // 
            // rdbtnPen
            // 
            this.rdbtnPen.AutoSize = true;
            this.rdbtnPen.Location = new System.Drawing.Point(13, 142);
            this.rdbtnPen.Name = "rdbtnPen";
            this.rdbtnPen.Size = new System.Drawing.Size(65, 29);
            this.rdbtnPen.TabIndex = 2;
            this.rdbtnPen.TabStop = true;
            this.rdbtnPen.Text = "Pen";
            this.rdbtnPen.UseVisualStyleBackColor = true;
            this.rdbtnPen.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // rdbtnMug
            // 
            this.rdbtnMug.AutoSize = true;
            this.rdbtnMug.Location = new System.Drawing.Point(13, 93);
            this.rdbtnMug.Name = "rdbtnMug";
            this.rdbtnMug.Size = new System.Drawing.Size(74, 29);
            this.rdbtnMug.TabIndex = 1;
            this.rdbtnMug.TabStop = true;
            this.rdbtnMug.Text = "Mug";
            this.rdbtnMug.UseVisualStyleBackColor = true;
            // 
            // rdbtnUSB
            // 
            this.rdbtnUSB.AutoSize = true;
            this.rdbtnUSB.Location = new System.Drawing.Point(13, 44);
            this.rdbtnUSB.Name = "rdbtnUSB";
            this.rdbtnUSB.Size = new System.Drawing.Size(69, 29);
            this.rdbtnUSB.TabIndex = 0;
            this.rdbtnUSB.TabStop = true;
            this.rdbtnUSB.Text = "USB";
            this.rdbtnUSB.UseVisualStyleBackColor = true;
            this.rdbtnUSB.CheckedChanged += new System.EventHandler(this.rdbtnUSB_CheckedChanged);
            // 
            // txtbxOrderNumber
            // 
            this.txtbxOrderNumber.Location = new System.Drawing.Point(224, 31);
            this.txtbxOrderNumber.Name = "txtbxOrderNumber";
            this.txtbxOrderNumber.Size = new System.Drawing.Size(150, 31);
            this.txtbxOrderNumber.TabIndex = 3;
            this.txtbxOrderNumber.TextChanged += new System.EventHandler(this.txtbxOrderNumber_TextChanged);
            // 
            // txtbxNumberOfItems
            // 
            this.txtbxNumberOfItems.Location = new System.Drawing.Point(224, 69);
            this.txtbxNumberOfItems.Name = "txtbxNumberOfItems";
            this.txtbxNumberOfItems.Size = new System.Drawing.Size(150, 31);
            this.txtbxNumberOfItems.TabIndex = 4;
            // 
            // lblTextInput
            // 
            this.lblTextInput.AutoSize = true;
            this.lblTextInput.Location = new System.Drawing.Point(20, 145);
            this.lblTextInput.Name = "lblTextInput";
            this.lblTextInput.Size = new System.Drawing.Size(180, 25);
            this.lblTextInput.TabIndex = 5;
            this.lblTextInput.Text = "Text to engrave/print:";
            // 
            // txtbxUserText
            // 
            this.txtbxUserText.AcceptsReturn = true;
            this.txtbxUserText.AcceptsTab = true;
            this.txtbxUserText.Location = new System.Drawing.Point(224, 145);
            this.txtbxUserText.Multiline = true;
            this.txtbxUserText.Name = "txtbxUserText";
            this.txtbxUserText.Size = new System.Drawing.Size(407, 75);
            this.txtbxUserText.TabIndex = 6;
            // 
            // lblNumberOfColors
            // 
            this.lblNumberOfColors.AutoSize = true;
            this.lblNumberOfColors.Location = new System.Drawing.Point(20, 108);
            this.lblNumberOfColors.Name = "lblNumberOfColors";
            this.lblNumberOfColors.Size = new System.Drawing.Size(155, 25);
            this.lblNumberOfColors.TabIndex = 7;
            this.lblNumberOfColors.Text = "Number of Colors";
            // 
            // txtbxNumberOfColors
            // 
            this.txtbxNumberOfColors.Location = new System.Drawing.Point(224, 105);
            this.txtbxNumberOfColors.Name = "txtbxNumberOfColors";
            this.txtbxNumberOfColors.Size = new System.Drawing.Size(150, 31);
            this.txtbxNumberOfColors.TabIndex = 8;
            // 
            // chkbxLogo
            // 
            this.chkbxLogo.AutoSize = true;
            this.chkbxLogo.Location = new System.Drawing.Point(433, 70);
            this.chkbxLogo.Name = "chkbxLogo";
            this.chkbxLogo.Size = new System.Drawing.Size(140, 29);
            this.chkbxLogo.TabIndex = 9;
            this.chkbxLogo.Text = "Add a Logo?";
            this.chkbxLogo.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(269, 238);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(112, 34);
            this.btnSubmit.TabIndex = 10;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(403, 238);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(112, 34);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtbxResults
            // 
            this.txtbxResults.Location = new System.Drawing.Point(12, 294);
            this.txtbxResults.Multiline = true;
            this.txtbxResults.Name = "txtbxResults";
            this.txtbxResults.ReadOnly = true;
            this.txtbxResults.Size = new System.Drawing.Size(776, 144);
            this.txtbxResults.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbxResults);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.chkbxLogo);
            this.Controls.Add(this.txtbxNumberOfColors);
            this.Controls.Add(this.lblNumberOfColors);
            this.Controls.Add(this.txtbxUserText);
            this.Controls.Add(this.lblTextInput);
            this.Controls.Add(this.txtbxNumberOfItems);
            this.Controls.Add(this.txtbxOrderNumber);
            this.Controls.Add(this.grpbxItemType);
            this.Controls.Add(this.lblNumberOfItems);
            this.Controls.Add(this.lblOrderNumber);
            this.Name = "Form1";
            this.Text = "Logo Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbxItemType.ResumeLayout(false);
            this.grpbxItemType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOrderNumber;
        private System.Windows.Forms.Label lblNumberOfItems;
        private System.Windows.Forms.GroupBox grpbxItemType;
        private System.Windows.Forms.RadioButton rdbtnPen;
        private System.Windows.Forms.RadioButton rdbtnMug;
        private System.Windows.Forms.RadioButton rdbtnUSB;
        private System.Windows.Forms.TextBox txtbxOrderNumber;
        private System.Windows.Forms.TextBox txtbxNumberOfItems;
        private System.Windows.Forms.Label lblTextInput;
        private System.Windows.Forms.TextBox txtbxUserText;
        private System.Windows.Forms.Label lblNumberOfColors;
        private System.Windows.Forms.TextBox txtbxNumberOfColors;
        private System.Windows.Forms.CheckBox chkbxLogo;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtbxResults;
    }
}
