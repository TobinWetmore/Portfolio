﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogoShop
{
    internal class LogoOrderItem
    {
        //Default object
        public LogoOrderItem() : this( false, "Placeholder") { }
        public LogoOrderItem(bool logo, string text) : this(logo, text, "Placeholder", 0.0M, 0, 0) { }

        public LogoOrderItem(bool logo, string text, string itemType, decimal itemPrice, int numColors, int numItems)
        {
            hasLogo = logo;
            this.itemType = itemType;
            this.itemPrice = itemPrice;
            this.numColors = numColors;
            this.numItems = numItems;
            Text = text;
            Calc();
            GetOrderSummary();
        }

        //The price to add a logo
        private static decimal logoPrice = 0.10M;
        //The price to add a color logo
        private static decimal colorPrice = 0.03M;

        //Order Number
        private int id;
        public int Id 
        {
            get { return id; } 
            set { id = value; }
        }
        //Track whether or not the item has a logo
        private bool hasLogo;
        public bool HasLogo
        {
            get { return hasLogo; }
            set { hasLogo = value; Calc(); }
        }
        //Item options are mug, pen, and USB drive. This is passed by logic in the the form.
        private string itemType;
        public string ItemType
        {
            get { return itemType; }
            set { itemType = value; Calc(); }
        }
		//The price for they type of item. This is passed by logic in the the form.
		private decimal itemPrice;
        public decimal ItemPrice
        {
            get { return itemPrice; }
            set { itemPrice = value; Calc(); }
        }
        //The number of colors the user wants to use on their item.
        private int numColors;
        public int NumColors
        {
            get { return numColors; }
            set { numColors = value; Calc(); }
        }
        //The number of items the user wants to order.
        private int numItems;
        public int NumItems
        {
            get { return numItems; }
            set { numItems = value; Calc(); }
        }
        //The text the user wants on the item.
        public string Text { get; set; }
        //The total price of the order, calculated internally by Calc().
        public decimal Price { get; private set; }

        //Calculate the price.
        private void Calc()
        {
            //Charge more for a logo
            if(HasLogo)
            {
                //Charge for each color
                Price = itemPrice + logoPrice + (numColors * colorPrice);
            }
            else
            {
                //Charge the usual amount for just text
                Price = itemPrice;
            }
            //Get the price for the full order.
            Price *= numItems;
            //Ensures that the price is set to round to cents.
			Math.Round(Price, 2);
		}

        public string GetOrderSummary()
        {
            string summary;
            //if statement for some gammar
            if (numItems > 1)
            {
                summary = "Order Number: " + id + ", Number of " + itemType + "s: " + numItems + "\r\nThe Text will be: \r\n\"" + Text + "\r\"";
            }
            else
            {
                summary = "Order Number: " + id + ", Number of " + itemType + ": " + numItems + "\r\nThe Text will be: \r\n\"" + Text + "\r\"";
            }
            if(HasLogo)
            {
                summary = summary + "\r\nThe logo has " + NumColors;
                //More grammar
                if(numColors > 1) { summary = summary + " colors."; }
                else { summary = summary + " color."; }
            }
            summary = summary + "\r\nThis order will cost a total of $" + Price + ".";
            return summary;
        }
    }
}
