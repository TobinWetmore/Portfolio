﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogoShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtbxResults.Clear();
            txtbxNumberOfColors.Clear();
            txtbxNumberOfItems.Clear();
            txtbxOrderNumber.Clear();
            txtbxUserText.Clear();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            LogoOrderItem order = new LogoOrderItem();

            //Simple Information
            try
            {
                order.Id = int.Parse(txtbxOrderNumber.Text);
                order.NumItems = int.Parse(txtbxNumberOfItems.Text);
            }
            catch( NotFiniteNumberException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch( MissingFieldException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong. \r\n Error: " + ex.Message);
            }

            order.Text = txtbxUserText.Text;

            //Logo Information
            if (chkbxLogo.Checked)
            {
                order.HasLogo = true;
                order.NumColors = int.Parse(txtbxNumberOfColors.Text);
            }

            //Item Type Information and pricing
            if(rdbtnMug.Checked)
            {
                order.ItemType = "Mug";
                order.ItemPrice = 3.50M;
            }
            else if(rdbtnPen.Checked)
            {
                order.ItemType = "Pen";
                order.ItemPrice = 1.00M;
            }
            else if(rdbtnUSB.Checked)
            {
                order.ItemType = "USB Drive";
                order.ItemPrice = 4.00M;
            }

            txtbxResults.Text = order.GetOrderSummary();
        }
        //Deleting these breaks the form, Looks like I double clicked on too much stuff

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblNumberOfItems_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void rdbtnUSB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtbxOrderNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
