#WetmoreP14
#Programmer:Tobin Wetmore
#email: twetmore@cnm.edu
#Final project: This program reads an external file with data on all aircraft that have had more than 5,000 units produced
#It then calculates more data based on that and write a file with it's findings
#Information about the aircraft was found at https://en.wikipedia.org/wiki/List_of_most-produced_aircraft
#I got rid of the data for the Schneider Grunau Baby because the data isn't great. It's technically still in production but
#only because enthusiasts are still making replicas. it's kinda messy

from operator import attrgetter

#An array of aircraft
aircraftArray = []

#A string that holds the file
fileContent = []

class Aircraft:
    #Constructor for the aircraft object
    def __init__(self, name = '', military = False, produced = 0, country = '', prodStart = 0, prodEnd = 0):
        self.name = name
        self.military = military
        self.produced = int(produced)
        self.country = country
        self.prodStart = int(prodStart)
        self.prodEnd = int(prodEnd)
        self.prodPeriod = 0
        self.annualAverageProduction = 0

    #Calculates the period over which the aircraft was produced
    def CalculateProductionPeriod(self):
        self.prodPeriod = self.prodEnd - self.prodStart

    #Calculates the Average production period of the aircraft
    def CalculateAverageProduction(self):
        self.annualAverageProduction = self.produced / self.prodPeriod

#Reads the file
#Information on file reading was found at https://stackoverflow.com/questions/21744804/python-read-comma-separated-values-from-a-text-file-then-output-result-to-tex
with open("C:/Python/Most_Produced_Aircraft.csv") as filestream:
    for line in filestream:
        #Breaks the line into an array
        currentline = line.split(",")

        #Defines if the aircraft is civilian or military
        if(currentline[1] == 'C'):
            militaryTemp = False
        else:
            militaryTemp = True

        #Defines when the aircraft ended production
        #If it's still in production, it sets prodEnd to 2020
        if(currentline[5] == 'present'):
            prodEndTemp = 2020
        else:
            prodEndTemp = currentline[5]

        #Constructs the aircraft
        newAircraft =  Aircraft(currentline[0], militaryTemp,int(currentline[2]), currentline[3],int(currentline[4]), prodEndTemp)

        aircraftArray.append(newAircraft)

        newAircraft.CalculateProductionPeriod()
        newAircraft.CalculateAverageProduction()

#Prints the most produced aircraft and adds it to the file
print('The ' + aircraftArray[0].name + ' is the most produced aircraft in the world, with ' + str(aircraftArray[0].produced) + ' made.\n')
fileContent.append('The ' + aircraftArray[0].name + ' is the most produced aircraft in the world, with ' + str(aircraftArray[0].produced) + ' made.\n')

#Waits until the user uses a correctly formatted input
#Or operator learned from https://www.programiz.com/python-programming/operators
cont0 = input("Would you like the full list added to the file? yes/no \n")
if cont0 == 'yes':
    for aircraft in aircraftArray:
        fileContent.append('Aircraft: ' + aircraft.name + '\n' + 'Number Produced: ' + str(aircraft.produced) + '\n\n')

#Sorts the aircraft array by the longest production period
#Information on sorting found at https://stackoverflow.com/questions/2338531/python-sorting-a-list-of-objects
#and https://docs.python.org/3/howto/sorting.html#sortinghowto
aircraftArray.sort(key = attrgetter('prodPeriod'), reverse = True)

#Prints the aircraft with the longest production period and adds it to the file
print('The ' + aircraftArray[0].name + ' has the longest production period, at ' + str(aircraftArray[0].prodPeriod) + ' years.\n')
fileContent.append('The ' + aircraftArray[0].name + ' has the longest production period, at ' + str(aircraftArray[0].prodPeriod) + ' years.\n')

#Waits until the user uses a correctly formatted input
#Or operator learned from https://www.programiz.com/python-programming/operators
cont1 = input("Would you like the full list added to the file? yes/no \n")
if cont1 == 'yes':
    for aircraft in aircraftArray:
        fileContent.append('Aircraft: ' + aircraft.name + '\n' + 'Production Period: ' + str(aircraft.prodPeriod) + '\n\n')

#Sorts the aircraft array by the highest annual average production
#Information on sorting found at https://stackoverflow.com/questions/2338531/python-sorting-a-list-of-objects
#and https://docs.python.org/3/howto/sorting.html#sortinghowto
aircraftArray.sort(key = attrgetter('annualAverageProduction'), reverse = True)

#Prints the aircraft with the highest annual average production and adds it to the file
print('The ' + aircraftArray[0].name + ' has the highest average units produced annually, at ' + str(aircraftArray[0].annualAverageProduction) + ' units per year.\n')
fileContent.append('The ' + aircraftArray[0].name + ' has the highest average units produced annually, at ' + str(aircraftArray[0].annualAverageProduction) + ' units per year.\n')

#Waits until the user uses a correctly formatted input
#Or operator learned from https://www.programiz.com/python-programming/operators
cont2 = input("Would you like the full list added to the file? yes/no \n")
if cont2 == 'yes':
    for aircraft in aircraftArray:
        fileContent.append('Aircraft: ' + aircraft.name + '\n' + 'Average Units Produced Annually: ' + str(aircraft.annualAverageProduction) + '\n\n')

#fileContent = 'potato'

#Ask the user what filename they want for the output then write the file
filename = input('What would you like to call the output file? Example: filename.txt\n')
outputFile = open(filename, 'w')
outputFile.writelines(fileContent)
outputFile.close()