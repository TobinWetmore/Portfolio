package com.cis2237.wetmorep2;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.cis2237.wetmorep2.databinding.FragmentMainBinding;

public class MainFragment extends Fragment
{
    //Declare some Class Variables
    //Cycles through the question array
    int questionIndex = 0;
    //number of questions answered correctly
    private int numberCorrect = 0;
    //number of questions answered incorrectly
    private int numberIncorrect = 0;
    //The user's grade
    private  double score = 0;
    //Whether or not the user has already answered a statement, so they can't pad stats on an known
    //answer
    private boolean answered = false;
    //View Variables so you can access them here
    private Button btnTrue;
    private Button btnFalse;
    private Button btnNext;
    private Button btnResults;
    //Strings for the toasts
    private String tst = "CIS 2237 Android Programming \r\nTobin Wetmore, Project 2";
    private String incorrectAnswer = "Incorrect";
    private String correctAnswer = "Correct";
    private FragmentMainBinding binding;
    public MainFragment() {
        // Required empty public constructor
    }
    public static MainFragment newInstance()
    {
        return new MainFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        binding = FragmentMainBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        btnTrue = binding.btnTrue;
        btnFalse = binding.btnFalse;
        btnNext = binding.btnNext;
        btnResults = binding.btnResults;

        //A toast for the program header

        //Anonymous event handlers for true/false
        binding.btnTrue.setOnClickListener(new View.OnClickListener()
        {@Override public void onClick(View v){checkAnswer(true);}});
        binding.btnFalse.setOnClickListener(new View.OnClickListener()
        {@Override public void onClick(View v){checkAnswer(false);}});

        binding.btnNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //increment the question and wrap it around to 0
                if(questionIndex == 19) { questionIndex = 0; }
                else { questionIndex++; }
                updateQuestion();
            }
        });

        binding.btnResults.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(numberIncorrect + numberCorrect != 0) { figureGrade(); }
                else { binding.tvwGrade.setText("Answer a question to see results"); }
            }
        });

        binding.btnCheat.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });

        updateQuestion();

        /*Figure this out
        setContentView(view);
        //Introductory Toast
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, tst,   Toast.LENGTH_LONG);
        toast.show();
        */

    }

    //Get the next question and display it
    private void updateQuestion()
    {
        binding.tvwQuestion.setText(Question.questionBank[questionIndex].getTextResID());
        answered = false;
    }

    //if the user pressed true, pass true, if false, pass false
    private void checkAnswer(boolean pressedTrue)
    {
        //Ensure the user isn't spamming known answers
        if (answered == false)
        {
            //Figure out if the user is correct
            boolean answer = Question.questionBank[questionIndex].isAnswerTrue();
            //Check the answer and increment numberCorrect or numberIncorrect
            if (pressedTrue == answer)
            {
                numberCorrect++;
                /*
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, correctAnswer,   Toast.LENGTH_LONG);
                toast.show();
                */
            } else
            {
                numberIncorrect++;
                /*
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, incorrectAnswer,   Toast.LENGTH_LONG);
                toast.show();
                */
            }
        }
        //Set
        answered = true;
    }

    private void figureGrade()
    {
        //Calculates the grade. The 100 is to make it worth the proper points.
        score = 100 * numberCorrect / (numberCorrect + numberIncorrect);
        String grade = "";
        if (score >= 90) { grade = String.valueOf(score) + ", A"; }
        else if (90 > score && score >= 80) { grade = String.valueOf(score) + ", B"; }
        else if (80 > score && score >= 70) { grade = String.valueOf(score) + ", C"; }
        else if (70 > score && score >= 60) { grade = String.valueOf(score) + ", D"; }
        else if (60 > score) { grade = String.valueOf(score) + ", F"; }
        //91-100: A
        //81-90: B
        //71-80: C
        //61-70: D
        //0-50: F

        binding.tvwGrade.setText(grade);
    }
}