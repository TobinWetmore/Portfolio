package com.cis2237.wetmorep2;

public class Question
{
    //Test for the question
    private int textResID;
    //Whether or not the statement is true
    private boolean answerTrue;

    //Create the question array
    public static final Question[] questionBank = new Question[]
            {
                    new Question(R.string.question_one,true),
                    new Question(R.string.question_two,true),
                    new Question(R.string.question_three,true),
                    new Question(R.string.question_four,true),
                    new Question(R.string.question_five,true),
                    new Question(R.string.question_six,true),
                    new Question(R.string.question_seven,true),
                    new Question(R.string.question_eight,true),
                    new Question(R.string.question_nine,true),
                    new Question(R.string.question_ten,true),
                    new Question(R.string.question_eleven,true),
                    new Question(R.string.question_twelve,true),
                    new Question(R.string.question_thirteen,true),
                    new Question(R.string.question_fourteen,true),
                    new Question(R.string.question_fifteen,true),
                    new Question(R.string.question_sixteen,true),
                    new Question(R.string.question_seventeen,true),
                    new Question(R.string.question_eighteen,true),
                    new Question(R.string.question_nineteen,true),
                    new Question(R.string.question_twenty,true),
            };

    //Constructor
    private Question(int textResID, boolean answerTrue)
    {
        this.textResID = textResID;
        this.answerTrue = answerTrue;
    }

    //Getter for textResID
    public int getTextResID() { return textResID; }

    //Getter for isAnswerTrue
    public boolean isAnswerTrue() { return answerTrue; }
}
