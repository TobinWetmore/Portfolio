package com.cis2237.wetmorep2;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cis2237.wetmorep2.databinding.FragmentCheatBinding;

public class CheatFragment extends Fragment
{

    public interface OnFragmentInteractionListener
    {
        void onFragmentInteraction(Uri uri);
    }
    private FragmentCheatBinding binding;
    public CheatFragment() {
        // Required empty public constructor
    }
    public static CheatFragment newInstance() { return new CheatFragment(); }

    @Override
    public void onStart()
    {
        super.onStart();
        CheatFragmentArgs args = CheatFragmentArgs.fromBundle(getArguments());
        String answer = args.getAnswer();
        binding.txtvwAnswer.setText(answer);
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }
    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        binding = FragmentCheatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
    }
}