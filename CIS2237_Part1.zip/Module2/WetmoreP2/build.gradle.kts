// Was in the Lecture from September 14th but throws all kinds of errors
/*buildscript{
    repositories{
        google()
    }
    dependencies{
        def nav_version = "2.6.0"
        classpath "androidx.navigation:navigation-safe-args-gradle-plugin:$nav_version"
    }
}
plugins {
    id("com.android.application") version "8.1.1" apply false
}

task clean(Delete){
    delete rootProject.buildDir
}
*/
// Top-level build file where you can add configuration options common to all sub-projects/modules.
// The version from the navigation demo
buildscript{
    dependencies{
        classpath("androidx.navigation:navigation-safe-args-gradle-plugin:2.5.3")
    }
}

plugins {
    id("com.android.application") version "8.1.1" apply false
}