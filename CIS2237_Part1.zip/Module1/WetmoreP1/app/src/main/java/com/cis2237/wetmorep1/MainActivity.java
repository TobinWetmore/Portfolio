/*
Tobin Wetmore
twetmore@cnm.edu
WetmoreP1
 */

package com.cis2237.wetmorep1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.dynamicanimation.animation.SpringAnimation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cis2237.wetmorep1.databinding.ActivityMainBinding;

import java.util.Locale;

public class MainActivity extends AppCompatActivity
{
    private ActivityMainBinding binding;

    //Declare some Class Variables
    //Cycles through the question array
    int questionIndex = 0;
    //number of questions answered correctly
    private int numberCorrect = 0;
    //number of questions answered incorrectly
    private int numberIncorrect = 0;
    //The user's grade
    private  double score = 0;
    //Whether or not the user has already answered a statement, so they can't pad stats on an known
    //answer
    private boolean answered = false;
    //View Variables so you can access them here
    private Button btnTrue;
    private Button btnFalse;
    private Button btnNext;
    private Button btnResults;
    //Strings for the toasts
    private String tst = "CIS 2237 Android Programming \r\nTobin Wetmore, Project 1";
    private String incorrectAnswer = "Incorrect";
    private String correctAnswer = "Correct";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();

        btnTrue = binding.btnTrue;
        btnFalse = binding.btnFalse;
        btnNext = binding.btnNext;
        btnResults = binding.btnResults;

        //A toast for the program header

        //Anonymous event handlers for true/false
        binding.btnTrue.setOnClickListener(new View.OnClickListener()
        {@Override public void onClick(View v){checkAnswer(true);}});
        binding.btnFalse.setOnClickListener(new View.OnClickListener()
        {@Override public void onClick(View v){checkAnswer(false);}});

        updateQuestion();

        setContentView(view);
        //Introductory Toast
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, tst,   Toast.LENGTH_LONG);
        toast.show();
    }

    //Methods for the onClicks

    public void pressNext(View view)
    {
        //increment the question and wrap it around to 0
        if(questionIndex == 19) { questionIndex = 0; }
        else { questionIndex++; }
        updateQuestion();
    }

    public void pressResults(View view)
    {
        if(numberIncorrect + numberCorrect != 0) { figureGrade(); }
        else { binding.tvwGrade.setText("Answer a question to see results"); }
    }

    //Get the next question and display it
    private void updateQuestion()
    {
        binding.tvwQuestion.setText(Question.questionBank[questionIndex].getTextResID());
        answered = false;
    }

    //if the user pressed true, pass true, if false, pass false
    private void checkAnswer(boolean pressedTrue)
    {
        //Ensure the user isn't spamming known answers
        if (answered == false)
        {
            //Figure out if the user is correct
            boolean answer = Question.questionBank[questionIndex].isAnswerTrue();
            //Check the answer and increment numberCorrect or numberIncorrect
            if (pressedTrue == answer)
            {
                numberCorrect++;
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, correctAnswer,   Toast.LENGTH_LONG);
                toast.show();
            } else
            {
                numberIncorrect++;
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, incorrectAnswer,   Toast.LENGTH_LONG);
                toast.show();
            }
        }
        //Set
        answered = true;
    }

    private void figureGrade()
    {
        //Calculates the grade. The 100 is to make it worth the proper points.
        score = 100 * numberCorrect / (numberCorrect + numberIncorrect);
        String grade = "";
        if (score >= 91) { grade = String.valueOf(score) + ", A"; }
        else if (91 > score && score >= 81) { grade = String.valueOf(score) + ", B"; }
        else if (81 > score && score >= 71) { grade = String.valueOf(score) + ", C"; }
        else if (71 > score && score >= 61) { grade = String.valueOf(score) + ", D"; }
        else if (61 > score) { grade = String.valueOf(score) + ", F"; }
        //91-100: A
        //81-90: B
        //71-80: C
        //61-70: D
        //0-50: F

        binding.tvwGrade.setText(grade);
    }
}